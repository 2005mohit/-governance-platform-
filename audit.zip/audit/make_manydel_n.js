const fs = require("fs");
const path = require("path");
const n = parseInt(process.argv[2] || "2000", 10);
const d = path.join(process.env.TEMP || "/tmp", "opencode", "manydel" + n);
fs.rmSync(d, { recursive: true, force: true });
fs.mkdirSync(d, { recursive: true });
let s = "import logging\n";
for (let i = 0; i < n; i++) {
  s += "def f" + i + "():\n    logging.info(\"x\")\n    db.delete(" + i + ")\n";
}
fs.writeFileSync(path.join(d, "many.py"), s);
console.log(d, "bytes", s.length);
