const fs = require("fs");
const path = require("path");
const d = path.join(process.env.TEMP || "/tmp", "opencode", "manydel");
fs.rmSync(d, { recursive: true, force: true });
fs.mkdirSync(d, { recursive: true });
let s = "import logging\n";
for (let i = 0; i < 20000; i++) {
  s += "def f" + i + "():\n    logging.info(\"x\")\n    db.delete(" + i + ")\n";
}
fs.writeFileSync(path.join(d, "many.py"), s);
console.log("bytes", s.length);
