# AI Risk Snapshot — independent audit

**Subject:** `ai-risk-snapshot` 1.1.0 (`C:\Users\Rachit\OneDrive\Documents\ai-risk-snapshot`)
**Audit type:** read-only source review, execution testing, adversarial corpus, legal-text cross-check.
**Date:** 2026-11-12. **Auditor environment:** Windows 11, Node 24.19.0, npm 11.17.0, Python 3.12.10.
**Scope:** does this tool work, as shipped, on real AI-agent codebases — and can a company rely on what it says?

Companion files:

| File | Contents |
|---|---|
| `audit/RULE_VALIDATION.md` | 12 rules: legal rating, quotes, precision/recall, FP/FN modes, keep/rework/drop |
| `audit/FINDINGS.csv` | 52 findings with severity, status, evidence, impact, recommendation |
| `audit/COMPETITOR_MATRIX.md` | verified capabilities of adjacent tools and the resulting position |
| `audit/CLAIMS_TO_FIX.md` | every public claim that is false or unverifiable, with the exact correction |
| `audit/INDIA_PACK_DESIGN.md` | design for the missing India/DPDP pack |
| `audit/ROADMAP.md` | 0–2 week / 1–2 month / 3–6 month plan with acceptance tests |

Reproduce the numbers:

```bash
cd ai-risk-snapshot
python audit/make_corpus.py          # writes 84 cases under audit/corpus/cases
node audit/run.js                    # writes audit/reports/metrics.json
node audit/schema_test.js            # malformed rule-pack probes
```

## 1. Answer first

**Can real AI companies use it on real agent codebases today?**

- **As a compliance or assurance artefact: no.** The output cites EU AI Act
  articles, but 0 of 12 rules rate *Strong* against the legal text, 3 carry at
  least one *wrong* article mapping, and the report never states the
  applicability conditions (high-risk classification, provider vs deployer,
  entry-into-force dates). Measured on 84 stated-intent cases: precision 0.548,
  recall 0.436 (TP 17 / FP 14 / FN 22 / TN 19).
- **As a CI gate: no.** The CLI exits 0 on every completed scan, including a
  6-finding / score-0 CRITICAL report. There is no SARIF, baseline, suppression,
  severity threshold, stable fingerprint, `schemaVersion`, config file, or
  `--pack` flag.
- **As a zero-install triage prompt for one developer: yes, with conditions.**
  It is genuinely local (no network calls observed, no code execution), fast on
  normal repositories, deterministic, and its HTML is correctly escaped. It is
  reasonable for "show me suspicious places to read next", not "tell me whether
  I comply".

**Verdict: not industry-ready. Usable only as a heuristic review aid, and only
if the report is re-labelled as review prompts rather than article findings.**

## 2. Scorecard

Scores are 0–5, where 3 is "acceptable for a prototype", 4 is "usable by an
external team", 5 is "defensible in procurement".

| Dimension | Score | Basis |
|---|---:|---|
| Architecture / design | 3 | Clear module split, one production dependency, read-only, no `eval` of scanned code. But file-level exposure, no plugin/config layer, hand-rolled parser, no schema. |
| Rule validity (legal) | 1 | 0 Strong, 9 Weak, 3 with a wrong article mapping (Art. 9 on IAM/SENSITIVE/SAFETY_BYPASS; Art. 9 instead of Art. 10 on data). |
| Detection accuracy | 1 | P 0.548 / R 0.436 on a purposive corpus; both FP and FN in 6 of 12 rules. |
| Report quality | 2 | Readable, escaped, fix text present. But "four risk areas", no applicability/role/dates, no confidence, no coverage matrix, score/band divergence. |
| Security of the tool | 3 | No code execution, output escaped, secrets masked. But high `js-yaml` DoS advisory, unconfined `--output` overwrite, pathological quadratic scan, raw crashes on bad packs. |
| Performance | 1 | 426 s for a 1.1 MB file with 20k `db.delete()`; 213 s for 50k files; 50k stderr lines. |
| Packaging | 3 | `npm pack` = 11 files, `ast_check.py` ships, LF/no BOM. No tests, no CI matrix, `engines >=16` untested. |
| Documentation truthfulness | 1 | `argparse`, India pack, 5-vs-12 rules, output location, AST claim — all false (F-43…F-48). |
| Legal alignment of output | 1 | Wrong mapping, no high-risk applicability, no role, no dates, no "not checked". |

**Aggregate: 16/45 (36%).**

## 3. What was verified to work

These are stated because they survived attempts to break them, not as praise:

- **No code execution.** A scanned file containing
  `open("…PWNED_AST.txt","w").write("executed")` did not create the file
  (`audit/scratch/asttests/noexec/pwn.py`; check returned `False`).
- **No network calls from the scanner.** All work is `fs` + `spawnSync` of a
  local Python interpreter; no HTTP client is imported (`src/*.js` imports are
  `fs`, `path`, `child_process`, `js-yaml`, `readline`, `os`).
- **Determinism.** Three runs of `test-baseline` were byte-identical after
  removing `generatedAt` (`audit/scratch/det{1,2,3}/norm.json`).
- **HTML escaping.** `</script><script>alert(1)</script>` in a snippet renders
  as `&lt;/script&gt;`; inline JSON uses `\u003c`; `a&b.py` renders as
  `a&amp;b.py`.
- **Secrets are masked in evidence** via `maskSecretMatches()`; IDENTITY_KEY
  snippets do not carry the key value (`src/utils.js:34–40`).
- **Baseline fixtures are stable:** `test-baseline` = 6 findings / score 0 /
  "Severe gap"; `test-baseline-agent` = 4 / 20; `test-baseline-commented` = 0 /
  100; `test-baseline-decisions` = 2 / 77.5.
- **No PII in the consent log:** only `timestamp`, `termsVersion`, `accepted`,
  `method` (`audit/reports/test-baseline/.consent-log.json`).

## 4. Known issues: confirmed or refuted

The brief listed nine suspected issues. All nine reproduce. Details and evidence:

| # | Known issue | Verdict | Evidence |
|---|---|---|---|
| 1 | Silent Python fallback | **CONFIRMED** | `src/scanner.js:561–569` probes `python3` then `python`; no warning if neither works. With `PATH` limited to Node, the same file produced `NO_HUMAN_LOOP:proximity-heuristic` (`audit/scratch/asttests/out4/report.json`). Python syntax errors and Python-2 files also fall back silently (`out2`, `out3`). |
| 2 | Tool exposure is file-level | **CONFIRMED** | `src/scanner.js:456`: `toolSignals.length > 0 ? "agent-tool" : "general-code"`; every finding in the file inherits it. One `@tool` decorator relabels unrelated `db.delete` findings. |
| 3 | Cross-function guard false positive | **CONFIRMED** | `nh_ev_helper_guard` (guard lives in `delete()`, call site flagged) is reported as `ast-confirmed`. `src/ast_check.py:168–208` walks only the enclosing function. |
| 4 | JS class-method / TS interface verbs matched as calls | **CONFIRMED** | `nh_fp_js_class`, `nh_fp_ts_interface` both produce `NO_HUMAN_LOOP` + `NO_LOGGING`. Definition filtering at `src/scanner.js:471–490` only understands `def` / `async def`. |
| 5 | Fixed English verb list | **CONFIRMED** | `rules/high_risk_actions.yaml` has 9 verbs. `db.remove(...)`, `"DELETE FROM …"`, `getattr(db,"delete")(…)` are all missed (`nh_ev_renamed`, `nh_ev_string_sql`, `nh_ev_dynamic`). |
| 6 | `SENSITIVE_DATA` is filename-only | **CONFIRMED** | `src/scanner.js:271–277`; `.json` is categorised as IaC at `:227`, so it is never name-checked. `customer_export.csv` and `customer_records.json` are FNs; `passport_template.png` and `report_1040.pdf` are FPs. |
| 7 | `NO_AI_DISCLOSURE` inspects the internal prompt | **CONFIRMED** | `src/scanner.js:631–680` reads the prompt body and matches "i am an AI". A user-facing `USER_NOTICE` does not satisfy it (`nd_ev_ui_disclosure` FP); an internal marker does (`nd_ev_internal_marker` FN). |
| 8 | Stale rule / benchmark counts (9 vs 12) | **CONFIRMED, with a third number** | Pack ships 12 (`rules/eu_ai_act.yaml`); revised paper benchmarks 9 (`RESEARCH_PAPER_REVISED.docx`, RQ1: "one … for each of nine rules"); README lists 5 (`README.md:62–66`). |
| 9 | Score / severity ceiling interaction | **CONFIRMED** | `src/reporter.js:24–45`. 1 CRITICAL → 75 "Severe gap"; 3 CRITICAL → 25 "Severe gap"; 1 HIGH → 85 "Elevated gap"; 6 HIGH → 10 "Elevated gap"; 20 MEDIUM → 0 "Severe gap"; 3 MEDIUM → 85 "Good readiness". The band ignores magnitude within a severity, and the score ignores the cap. |

## 5. New issues worth more than some of the known ones

### 5.1 The report never states applicability (highest credibility risk)
`src/reporter.js:47–63` and `:406–409` contain only "not a certified compliance
audit / not legal advice". There is no statement that Arts. 9, 12, 14 and 15
apply **only to high-risk systems**, no Annex I/III classification, no
provider/deployer role, and no entry-into-force date. The paper says all of this
(`RESEARCH_PAPER_REVISED.docx` §2); the artefact the customer keeps does not.
A reader can reasonably treat "Article 14 (Human Oversight)" as an applicable
legal finding. This is the single biggest risk to credibility, because it is the
gap between what the project knows and what it ships.

### 5.2 Two rules map to the wrong article
- `SENSITIVE_DATA` → shipped `Article 9 & 15` (`rules/eu_ai_act.yaml:286`), while
  the paper says Art. 10 / GDPR. Art. 10 is data governance; Art. 9 is a
  process duty. The output contradicts the paper.
- `IAM_WILDCARD` and `SAFETY_BYPASS` present Art. 9 as co-equal
  (`:37`, `:409`). A wildcard IAM policy or a disabled flag is not evidence
  about a risk-management system.

### 5.3 CI/enterprise surface is absent
Verified by source reading and execution: exit 0 on findings, no SARIF, no
baseline, no suppression, no threshold, no `--format`, no `--rules`, no config,
no `schemaVersion`, no fingerprint, no incremental scan, no monorepo support.
`parseArgs` (`src/cli.js:12–37`) silently ignores unknown flags, so `--ouput out`
scans the current directory and writes the default report with exit 0.

### 5.4 One generated file can hang the scan
Candidate handling is quadratic. Measured on one file:

| `db.delete()` calls | File size | With Python | Python absent |
|---:|---:|---:|---:|
| 2,000 | 108 KB | 20.3 s | 2.2 s |
| 5,000 | 273 KB | 38.2 s | 23.3 s |
| 20,000 | 1.12 MB | **411.5 s** | — |

The AST helper is invoked per query inside the candidate loop; each `spawnSync`
costs ~15 ms. A generated agent file (or a vendored SDK) can therefore stall CI
for minutes. At repo scale: 5,000 files = 20.3 s, 50,000 files = 213.1 s, peak
RSS ≈ 84 MB, and 50,000 progress lines on stderr.

### 5.5 Rule packs can crash or silently neuter the scan
`audit/schema_test.js` (run against generated packs under `audit/scratch/schema/`):

| Pack defect | Observed |
|---|---|
| Invalid regex | `SyntaxError: Invalid regular expression: /(/g: Unterminated group` — aborts scan |
| Missing `rules` key | `TypeError: this.rules is not iterable` |
| `rules` is a string | `TypeError: this.rules.find is not a function` |
| Severity `SUPER` | Accepted; finding produced with **0 penalty** |
| No `patterns`/`logic` | Accepted; 0 findings, no warning |
| Dangling `actionsRef` | Clear error (the one good case) |

### 5.6 Dependency and output-path risks
- `js-yaml` 4.3.1 is installed and `npm audit` reports **high**
  (GHSA-2883-xcg3-v3hh, CWE-400/407, `maxTotalMergeKeys` CPU DoS). Rule packs are
  untrusted input in a "pluggable YAML" product.
- `--output` is resolved without confinement and `report.json` / `report.html`
  are overwritten unconditionally (`src/reporter.js:465–466`), so a typo can
  clobber an existing report pair.
- A junction loop terminated in 1.66 s without a warning — safe, but silent.

### 5.7 Modern agent frameworks are mostly invisible
`src/scanner.js:100–109` detects LangChain `@tool`, CrewAI `tools=[…]`, AutoGen
`function_map`, OpenAI function schema, and LangChain JS `tool()`. It **misses**
LangGraph `ToolNode`, OpenAI Agents SDK `@function_tool`, Anthropic tool schema,
MCP `@server.tool()`, Semantic Kernel `add_function`, LlamaIndex
`FunctionTool`, and Pydantic AI `@agent.tool` — i.e. most of the 2025–26 stack.
Because `toolExposure` drives the finding title, missed frameworks silently
downgrade findings to "general code risk".

## 6. Accuracy: the measured picture

Corpus: 84 cases, one target rule per case, expectations written from the rule's
stated intent before execution. This is purposive, not a random sample.

| Rule | TP | FP | FN | TN | Precision | Recall |
|---|---:|---:|---:|---:|---:|---:|
| IDENTITY_KEY | 2 | 0 | 3 | 3 | 1.00 | 0.40 |
| IAM_WILDCARD | 1 | 0 | 2 | 2 | 1.00 | 0.33 |
| NO_HUMAN_LOOP | 4 | 5 | 3 | 4 | 0.44 | 0.57 |
| NO_LOGGING | 2 | 2 | 0 | 1 | 0.50 | 1.00 |
| NO_AI_DISCLOSURE | 1 | 1 | 2 | 1 | 0.50 | 0.33 |
| HTTP_NO_AUTH | 1 | 1 | 0 | 2 | 0.50 | 1.00 |
| AUTO_DECISION | 1 | 1 | 2 | 1 | 0.50 | 0.33 |
| CORS_WILDCARD | 1 | 0 | 2 | 1 | 1.00 | 0.33 |
| SENSITIVE_DATA | 1 | 2 | 2 | 0 | 0.33 | 0.33 |
| UNSAFE_DESERIALIZE | 1 | 0 | 3 | 2 | 1.00 | 0.25 |
| ERROR_LEAKAGE | 1 | 1 | 2 | 1 | 0.50 | 0.33 |
| SAFETY_BYPASS | 1 | 1 | 1 | 1 | 0.50 | 0.50 |
| **Total** | **17** | **14** | **22** | **19** | **0.548** | **0.436** |

Two things follow:

1. The paper's "1.00 precision / 0.78 recall" describes 18 constructed fixtures
   over 9 rules. It does not predict field behaviour, and the authors say so
   ("does not estimate field precision"). The gap (0.548 / 0.436) is the useful
   number for a buyer.
2. Precision is worst exactly where the legal claim is strongest
   (`NO_HUMAN_LOOP` at 0.44, `SENSITIVE_DATA` at 0.33). Those are the findings a
   user is most likely to forward to a compliance lead.

## 7. Legal alignment

Source: `artificialintelligenceact.eu` article pages saved in
`audit/scratch/art{6,9,10,12,14,15,26,50,99}.txt`. EUR-Lex returned HTTP 202 with
an empty body, so this is secondary-but-official-text mirroring; quote-level
checks were cross-read against the saved pages. Not legal advice.

| Requirement | What the Act says | What the tool does | Gap |
|---|---|---|---|
| High-risk gate | Arts. 9/12/14/15 apply to high-risk systems (Art. 6, Annexes I/III) | Never classifies; assumes high-risk use | Not disclosed in output |
| Actor | Provider designs (Arts. 9/12/14/15); deployer duties in Art. 26 | No role model | Findings can attribute provider duties to a deployer |
| Art. 9 | "A risk management system shall be established … in relation to high-risk AI systems" | Fires on wildcard IAM, sensitive filenames, disabled flags | Wrong: no process evidence |
| Art. 10 | "data governance and management practices" for training/validation/test data | `SENSITIVE_DATA` cites Art. 9/15 | Wrong article (paper says Art. 10) |
| Art. 12 | "automatic recording of events (logs) over the lifetime" | Looks for a logging token within 15 lines | Weak: not system-level |
| Art. 14 | "effectively overseen by natural persons" | Looks for 6 English approval identifiers | Weak: marker list, not oversight design |
| Art. 15(5) | "resilient against attempts by unauthorised third parties to alter their use" | Fires on secrets, IAM, CORS, errors, deserialization, endpoints | Weak: security indicator, not resilience proof |
| Art. 50(1) | "informed that they are interacting with an AI system" | Reads the system-prompt body | Wrong artefact |
| Dates | 2 Dec 2027 (Annex III) / 2 Aug 2028 (Annex I), Art. 113(c) | No date anywhere | Missing |
| Penalties | Art. 99 tiers, e.g. €35M/7% for prohibited practices | Not mentioned | Not a defect, but buyers will ask |

The report also says "Where we looked - four risk areas the EU AI Act covers"
(`src/reporter.js:386`). The pack actually spans five articles and 12 rules, and
"areas" is computed from finding count, not coverage. That sentence is the most
legally loaded sentence in the product and should be removed first.

## 8. Security review of the tool itself

| Test | Result |
|---|---|
| Executes scanned code? | No — `open(...).write(...)` did not run. |
| Network egress? | None found: no `http`/`https`/`fetch` in `src/`. |
| HTML injection via snippet | Escaped (`&lt;/script&gt;`), inline JSON `\u003c`. |
| HTML injection via filename | Escaped (`a&amp;b.py`). |
| Path traversal via filename | No evidence of path use beyond display. |
| Symlink/junction loop | Terminates in 1.66 s; no warning. |
| `--output` abuse | Writes/overwrites report pair anywhere writable. |
| Rule-pack DoS | Invalid regex aborts; js-yaml advisory; alias bomb (small) fine. |
| Regex DoS on 1 MB inputs | 228–947 ms for `a`s, quotes, `sk-`, `Action =`, `torch.load(`, `a.`, NUL/binary. |
| Algorithmic DoS | 20k-action file = 411 s (see §5.4). |
| Dependency audit | 1 high (`js-yaml`), 0 critical. |
| Secret in report | Masked by `maskSecretMatches`; PII redaction for email/SSN/card/phone. |

No remote-code-execution or XSS finding. The realistic security risks are
availability (quadratic scan, YAML advisory) and accidental overwrite.

## 9. Report and UX

- **Score/band**: the two axes disagree (see §4 #9). The band is capped by worst
  severity but never softened by score, and the score ignores severity caps, so
  a 10/100 report with six HIGHs says "Elevated gap" while a 0/100 report with
  20 MEDIUMs says "Severe gap".
- **No confidence per finding in HTML**: `method` exists in JSON but the card
  comment at `src/reporter.js:65–69` says `whatItChecks`/`falsePositiveNote` are
  not rendered. A user cannot see "ast-confirmed" vs "proximity-heuristic".
- **Silent truncation**: `maxFindings: 5` on `NO_AI_DISCLOSURE`; the report says
  "5+" nowhere.
- **No "not checked" section**: absence of a finding is presented as a clean
  area.
- **No remediation ordering**: fixes are per-card, not prioritised.
- **CTA accuracy**: `src/cli.js:154` ("reach out with report.json if you'd like a
  full audit") and `src/reporter.js:397` are service offers, not factual claims
  about the scan; they do not overstate the scanner. One nuance: report.json
  contains code snippets (PII-redacted, secrets masked), so sending it shares
  source excerpts; the terms say the contents are treated as confidential
  (`src/agreement.js:29–33`), which is consistent. **No change required to the
  lead-gen line.**

## 10. Packaging, install, and environment

- `npm pack --dry-run`: 11 files, 39.8 kB tarball, 118.3 kB unpacked;
  `src/`, `rules/`, README, LICENSE, package.json. `audit/` is excluded.
  `src/ast_check.py` is included and has a shebang; `cli.js` and `ast_check.py`
  are LF-only with no BOM.
- `package.json`: `engines.node >=16.0.0`; only Node 24.19.0 was available here
  (no global installs permitted), so 16/18/20/22 support is **UNVERIFIED**. The
  code uses `??`, regex lookbehind, `fs.rmSync` — all Node 14+, so 16 is
  plausible but untested.
- `python3` on this Windows host is the Microsoft Store stub: status 9009, then
  the probe falls through to `python` (status 0). No README/console notice.
- `npm start` = `node src/cli.js`; there is **no test script and no test
  directory**. `test-baseline*` are fixtures, not assertions.
- The only production dependency is `js-yaml` (MIT). No SBOM or third-party
  notices; low risk at one dependency, but a procurement checklist will ask.

## 11. Competitive position (verified facts only)

Full matrix in `audit/COMPETITOR_MATRIX.md`. The short version:

- **AIR Blackbox MCP** — open-source MCP server for EU AI Act scanning, 6
  articles, Python/notebooks/TS/JS/Java/Kotlin, includes remediation and action
  validation, Apache-2.0. This is the closest direct competitor and is broader
  on language coverage.
- **compliance-agent 0.6.1** (PyPI) — EU AI Act scanner, MIT.
- **Semgrep** — 30+ languages, local by default, SARIF, 20k+ proprietary rules;
  the obvious "just use Semgrep" objection.
- **Gitleaks / Checkov / Bandit** — secrets, IaC, Python AST; each is
  feature-complete in its niche and all are free.
- **garak / promptfoo** — LLM red-teaming and evals; complementary, not
  competing.
- No verifiable product found that combines static agent-code indicators with a
  *credible* legal mapping for both EU and India. That is the only open niche,
  and it is currently occupied by marketing language rather than validated
  checks.

## 12. Limits of this audit

- One Windows host; no macOS/Linux runs. No Node 16/18/20/22 matrix.
- The corpus is purposive (84 cases, one rule each), not a random sample of
  repositories. Rates are directional; confidence intervals would be wide.
- Legal review is against mirrored article text, not counsel-reviewed; the
  audit checks whether the *tool's* mapping matches the article, not whether the
  article applies to a specific product.
- Competitor facts come from official repos/PyPI/READMEs on 2026-11-12; no
  hands-on benchmark of competitor precision.
- "Industry-ready" is judged against CI, procurement, and compliance workflows,
  not against "useful to one developer".

## 13. Bottom line

The engine is honest about being heuristic in its README and paper, but the
artefact it produces is not: it prints article numbers, a 0–100 score, and a
severity band, with none of the conditions that make those labels meaningful.
The fastest route to credibility is not more rules — it is to remove or qualify
the legal claims, fix the three wrong mappings, surface applicability and
method per finding, and make the output usable in CI. Until then, a company can
use it to decide what to read next; it cannot use it to decide whether it
complies.
