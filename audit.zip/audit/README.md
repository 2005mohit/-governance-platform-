# Audit workspace

Read-only audit of `ai-risk-snapshot` 1.1.0. Nothing outside this folder was
modified. Start with `AUDIT_REPORT.md`.

| File | Purpose |
|---|---|
| `AUDIT_REPORT.md` | Main report: verdict, scorecard, known-issue confirmation, new findings, legal and security review |
| `RULE_VALIDATION.md` | Per-rule legal rating, quotes, measured precision/recall, FP/FN modes, keep/rework/drop |
| `FINDINGS.csv` | 52 findings: area, severity, status, evidence, impact, recommendation |
| `COMPETITOR_MATRIX.md` | Verified capabilities of adjacent tools and the resulting market position |
| `CLAIMS_TO_FIX.md` | Every false/unverifiable public claim with exact replacement wording |
| `INDIA_PACK_DESIGN.md` | DPDP/CERT-In/MeitY/RBI pack design, detectors, fixtures, schema changes |
| `ROADMAP.md` | 0–2 week / 1–2 month / 3–6 month plan, acceptance tests, pilot checklist |

## Reproduce

```bash
cd ai-risk-snapshot
python audit/make_corpus.py    # 84 cases under audit/corpus/cases
node audit/run.js              # writes audit/reports/metrics.json
node audit/schema_test.js      # malformed rule-pack probes
```

Supporting artefacts:

- `audit/corpus/manifest.json` — case metadata and pre-registered expectations.
- `audit/reports/metrics.json` — per-rule TP/FP/FN/TN, per-case outcomes,
  framework detection results.
- `audit/reports/test-baseline*/` — the four gate fixtures (6 / 4 / 0 / 2 findings).
- `audit/scratch/art*.txt` — EU AI Act article text (source:
  `artificialintelligenceact.eu`; EUR-Lex returned HTTP 202 with an empty body).
- `audit/scratch/schema/` — generated malformed packs used by `schema_test.js`.
- `audit/scratch/asttests/` — Python fallback, syntax-error, Python-2, and
  no-execution probes.
- `audit/make_redos.js`, `audit/make_manydel*.js`, `audit/make_repo.js` —
  generators for the performance tests; they write only to the OS temp folder.

## Status labels

| Label | Meaning |
|---|---|
| **VERIFIED** | Re-derived from code, a command + output, or a primary/official source in this workspace. |
| **INFERRED** | Follows from verified facts but was not directly executed; the reasoning is stated. |
| **UNVERIFIED** | Not testable in this environment (e.g. Node 16/18/20/22, blocked PDF sources). |

## Environment

Windows 11, Node 24.19.0, npm 11.17.0, Python 3.12.10. Only one Node version was
available because global installs were out of scope, so Node-version
compatibility is marked UNVERIFIED.
