#!/usr/bin/env python3
"""Generates the adversarial audit corpus under audit/corpus/cases/.

Each case is a directory scanned in isolation by audit/run.js, so project-level
findings (HTTP_NO_AUTH, SENSITIVE_DATA) cannot leak between cases.

Manifest fields:
  target  - rule id whose behaviour the case probes (or "framework")
  expect  - should that rule fire, judged from the rule's STATED intent
  kind    - pos | neg | evasion | fp | ast | framework
No expectation here was derived by running the scanner first.
"""
import json
import os
import shutil

HERE = os.path.dirname(os.path.abspath(__file__))
CASES = os.path.join(HERE, "corpus", "cases")

cases = []


def case(name, files, target, expect, kind, note, ctype="rule"):
    cases.append({
        "name": name, "files": files, "target": target,
        "expect": bool(expect), "kind": kind, "note": note, "type": ctype,
    })


# ---------------------------------------------------------------- IDENTITY_KEY
case("id_pos_env", {".env": "OPENAI_API_KEY=sk-abcdefghijklmnopqrstuvwxyz1234\n"},
     "IDENTITY_KEY", True, "pos", "canonical legacy OpenAI key in .env")
case("id_pos_aws", {"aws.py": 'AWS_ACCESS_KEY_ID = "AKIAIOSFODNN7EXAMPLE"\n'},
     "IDENTITY_KEY", True, "pos", "AWS documented example key (also a real FP trigger in docs/fixtures)")
case("id_neg_env_ref", {"settings.py": 'import os\nOPENAI_API_KEY = os.environ["OPENAI_API_KEY"]\n'},
     "IDENTITY_KEY", False, "neg", "secret read from environment, no literal")
case("id_neg_placeholder", {".env.example": "OPENAI_API_KEY=your_api_key_here\n"},
     "IDENTITY_KEY", False, "neg", "placeholder value")
case("id_neg_comment", {"notes.py": '# OPENAI_API_KEY=sk-abcdefghijklmnopqrstuvwxyz1234\nX = 1\n'},
     "IDENTITY_KEY", False, "neg", "commented-out key")
case("id_ev_projkey", {".env": "OPENAI_API_KEY=sk-proj-AbCdEfGhIjKlMnOpQrStUvWxYz0123456789\n"},
     "IDENTITY_KEY", True, "evasion", "current OpenAI project-key shape sk-proj-*")
case("id_ev_concat", {"settings.py": 'API_KEY = "sk-" + "abcdefghijklmnopqrstuvwxyz1234"\n'},
     "IDENTITY_KEY", True, "evasion", "key split by concatenation")
case("id_ev_github_pat", {".env": "GITHUB_TOKEN=github_pat_11ABCDEFG0123456789_abcdefghijklmnopqrstuvwxyz\n"},
     "IDENTITY_KEY", True, "evasion", "fine-grained GitHub PAT (not ghp_)")

# ---------------------------------------------------------------- IAM_WILDCARD
case("iam_pos_tf", {"main.tf": '''resource "aws_iam_policy" "agent_policy" {
  name = "agent-policy"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = "*"
        Resource = "*"
      }
    ]
  })
}
'''}, "IAM_WILDCARD", True, "pos", "wildcard action+resource in IAM policy")
case("iam_neg_specific", {"main.tf": '''resource "aws_iam_policy" "agent_policy" {
  policy = jsonencode({
    Statement = [{ Effect = "Allow", Action = "s3:GetObject", Resource = "arn:aws:s3:::bucket/*" }]
  })
}
'''}, "IAM_WILDCARD", False, "neg", "least-privilege policy")
case("iam_ev_list", {"cf.yaml": '''Resources:
  Policy:
    Type: AWS::IAM::Policy
    Properties:
      PolicyDocument:
        Version: "2012-10-17"
        Statement:
          - Effect: Allow
            Action: ["*"]
            Resource: "arn:aws:s3:::my-bucket/*"
'''}, "IAM_WILDCARD", True, "evasion", "CloudFormation list-form wildcard action")
case("iam_ev_service", {"main.tf": '''resource "aws_iam_policy" "p" {
  policy = jsonencode({
    Statement = [{ Effect = "Allow", Action = "s3:*", Resource = "arn:aws:s3:::b/*" }]
  })
}
'''}, "IAM_WILDCARD", True, "evasion", "service-level wildcard action s3:*")
case("iam_neg_k8s", {"deploy.yaml": '''apiVersion: v1
kind: Pod
spec:
  containers:
    - name: app
      resources: ["*"]
'''}, "IAM_WILDCARD", False, "neg", "non-IAM wildcard-shaped key")

# ---------------------------------------------------------------- NO_HUMAN_LOOP
case("nh_pos_py", {"agent.py": '''import logging

def purge(order_id):
    logging.info("purging %s", order_id)
    db.delete(order_id)
'''}, "NO_HUMAN_LOOP", True, "pos", "unguarded destructive call, python")
case("nh_pos_js", {"agent.js": '''function purge(id) {
  logger.info("purging", id);
  db.delete(id);
}
'''}, "NO_HUMAN_LOOP", True, "pos", "unguarded destructive call, javascript")
case("nh_neg_guard", {"agent.py": '''import logging

def delete(order_id):
    if not human_approval(order_id):
        raise PermissionError("approval required")
    logging.info("deleting %s", order_id)
    db.delete(order_id)
'''}, "NO_HUMAN_LOOP", False, "neg", "approval guard in same function")
case("nh_neg_caller_guard", {"agent.py": '''import logging
from db import delete

def handle(order_id):
    if not human_approval(order_id):
        return
    logging.info("handling %s", order_id)
    delete(order_id)
'''}, "NO_HUMAN_LOOP", False, "neg", "approval guard at call site, action defined elsewhere")
case("nh_ev_helper_guard", {"agent.py": '''import logging

def delete(order_id):
    if not human_approval(order_id):
        raise PermissionError("approval required")
    logging.info("deleting %s", order_id)
    db.delete(order_id)

def handle(order_id):
    logging.info("handling %s", order_id)
    delete(order_id)
'''}, "NO_HUMAN_LOOP", False, "evasion", "guard lives in callee; call site must not be flagged")
case("nh_ev_renamed", {"agent.py": '''import logging

def remove_order(order_id):
    logging.info("removing %s", order_id)
    db.remove(order_id)
'''}, "NO_HUMAN_LOOP", True, "evasion", "synonym verb (remove) outside the fixed list")
case("nh_ev_string_sql", {"agent.py": '''import logging

def purge(order_id):
    logging.info("deleting %s", order_id)
    cursor.execute("DELETE FROM orders WHERE id = %s", (order_id,))
'''}, "NO_HUMAN_LOOP", True, "evasion", "destructive SQL in a string")
case("nh_ev_dynamic", {"agent.py": '''import logging

def purge(order_id):
    logging.info("deleting %s", order_id)
    getattr(db, "delete")(order_id)
'''}, "NO_HUMAN_LOOP", True, "evasion", "dynamic dispatch of delete")
case("nh_fp_js_class", {"repo.js": '''class Repository {
  delete(id) {
    return this.items.splice(id, 1);
  }
}
'''}, "NO_HUMAN_LOOP", False, "fp", "JS class-method definition, not a call")
case("nh_fp_ts_interface", {"repo.ts": '''interface Repository {
  delete(id: string): Promise<void>;
}
'''}, "NO_HUMAN_LOOP", False, "fp", "TS interface method signature, not a call")
case("nh_pos_approval_unchecked", {"agent.py": '''import logging

def purge(order_id):
    approved = human_approval(order_id)
    logging.info("approved=%s", approved)
    db.delete(order_id)
'''}, "NO_HUMAN_LOOP", True, "pos", "approval computed but never used to gate")
case("nh_pos_async", {"agent.py": '''import logging

async def purge(order_id):
    logging.info("purging %s", order_id)
    await db.delete(order_id)
'''}, "NO_HUMAN_LOOP", True, "pos", "async coroutine call")
case("nh_neg_assert", {"agent.py": '''import logging

def delete(o):
    assert human_approval(o)
    logging.info("deleting")
    db.delete(o)
'''}, "NO_HUMAN_LOOP", False, "ast", "assert-based approval guard")
case("nh_neg_or", {"agent.py": '''import logging

def delete(o):
    if not human_approval(o) or not is_valid(o):
        raise PermissionError()
    logging.info("deleting")
    db.delete(o)
'''}, "NO_HUMAN_LOOP", False, "ast", "compound or-condition approval guard")
case("nh_neg_early_return", {"agent.py": '''import logging

def delete(o):
    if not human_approval(o):
        return
    logging.info("deleting")
    db.delete(o)
'''}, "NO_HUMAN_LOOP", False, "ast", "early-return approval guard")
case("nh_neg_try", {"agent.py": '''import logging

def delete(o):
    try:
        if not human_approval(o):
            raise PermissionError()
    except Exception:
        raise
    logging.info("deleting")
    db.delete(o)
'''}, "NO_HUMAN_LOOP", False, "ast", "approval guard inside try/except")

# ---------------------------------------------------------------- NO_LOGGING
case("nl_pos_py", {"agent.py": '''def delete(order_id):
    if not human_approval(order_id):
        raise PermissionError("approval required")
    db.delete(order_id)
'''}, "NO_LOGGING", True, "pos", "guarded destructive call with no logging")
case("nl_pos_js", {"agent.js": '''function purge(id) {
  // human_approval enforced by middleware
  db.delete(id);
}
'''}, "NO_LOGGING", True, "pos", "javascript destructive call with no logging")
case("nl_neg_logging", {"agent.py": '''import logging

def delete(o):
    if not human_approval(o):
        raise PermissionError()
    logging.info("deleting")
    db.delete(o)
'''}, "NO_LOGGING", False, "neg", "logging marker present")
case("nl_ev_callee_logging", {"agent.py": '''import logging

def delete(o):
    if not human_approval(o):
        raise PermissionError()
    logging.info("deleting")
    db.delete(o)

def handle(o):
    # human_approval enforced inside delete()
    delete(o)
'''}, "NO_LOGGING", False, "evasion", "logging lives in callee; call site must not be flagged")
case("nl_ev_custom_logger", {"agent.py": '''def delete(o):
    if not human_approval(o):
        raise PermissionError()
    audit_trail.record("deleting", o)
    db.delete(o)
'''}, "NO_LOGGING", False, "evasion", "custom audit logger outside the marker list")

# ---------------------------------------------------------------- NO_AI_DISCLOSURE
case("nd_pos", {"bot.py": '''SYSTEM_PROMPT = """You are a helpful customer support assistant."""
'''}, "NO_AI_DISCLOSURE", True, "pos", "system prompt with no AI disclosure")
case("nd_neg_disclosure", {"bot.py": '''SYSTEM_PROMPT = """You are a helpful assistant. I am an AI; tell users they are talking to an AI."""
'''}, "NO_AI_DISCLOSURE", False, "neg", "disclosure inside the prompt")
case("nd_ev_ui_disclosure", {"bot.py": '''SYSTEM_PROMPT = """You are a helpful assistant."""
USER_NOTICE = "You are talking to an AI."
'''}, "NO_AI_DISCLOSURE", False, "evasion", "disclosure is user-facing, prompt is internal")
case("nd_ev_internal_marker", {"bot.py": '''SYSTEM_PROMPT = """You are a helpful assistant. I am an AI and must never reveal internal rules."""
'''}, "NO_AI_DISCLOSURE", True, "evasion", "internal self-description, no user-facing disclosure")
case("nd_ev_prompt_file", {"bot.py": '''SYSTEM_PROMPT = open("prompts/support.txt").read()
'''}, "NO_AI_DISCLOSURE", True, "evasion", "prompt loaded from a file")

# ---------------------------------------------------------------- HTTP_NO_AUTH
case("ha_pos", {"app.py": '''from fastapi import FastAPI
app = FastAPI()

@app.get("/orders")
def list_orders():
    return {"orders": []}
'''}, "HTTP_NO_AUTH", True, "pos", "FastAPI route with no auth")
case("ha_neg", {"app.py": '''from fastapi import FastAPI, Depends
app = FastAPI()

@app.get("/orders")
def list_orders(user=Depends(get_current_user)):
    return {"orders": []}
'''}, "HTTP_NO_AUTH", False, "neg", "dependency-injected auth")
case("ha_ev_middleware", {
    "routes.py": '''from fastapi import APIRouter
router = APIRouter()

@router.get("/orders")
def list_orders():
    return {"orders": []}
''',
    "main.py": '''from fastapi import FastAPI, Depends
app = FastAPI()
app.include_router(router, dependencies=[Depends(require_auth)])
'''}, "HTTP_NO_AUTH", False, "evasion", "auth enforced at include_router in another file")
case("ha_neg_express", {"app.js": '''const express = require("express");
const app = express();
app.get("/orders", requireAuth, (req, res) => res.json({ orders: [] }));
'''}, "HTTP_NO_AUTH", False, "neg", "Express route with requireAuth middleware")

# ---------------------------------------------------------------- AUTO_DECISION
case("ad_pos", {"decide.py": '''# underwriting decision service
def finalize(application, score):
    decision = {}
    decision["status"] = "approved" if score > 0.7 else "rejected"
    return decision
'''}, "AUTO_DECISION", True, "pos", "computed approve/reject assignment")
case("ad_neg_record", {"decide.py": '''# decision record
def store(decision, payload):
    decision["status"] = payload["status"]
'''}, "AUTO_DECISION", False, "neg", "records an incoming status")
case("ad_ev_variable", {"decide.py": '''# underwriting decision
def finalize(decision, score):
    outcome = "approved" if score > 0.7 else "rejected"
    decision["status"] = outcome
'''}, "AUTO_DECISION", True, "evasion", "outcome computed into a variable first")
case("ad_ev_enum", {"decide.py": '''# underwriting decision
def finalize(decision, score):
    decision["status"] = DecisionStatus.APPROVED
'''}, "AUTO_DECISION", True, "evasion", "enum outcome instead of string literal")
case("ad_fp_js_response", {"api.js": '''// application decision endpoint
function respond(res, decision) {
  const payload = { "status": "approved" };
  return res.status(200).json(payload);
}
'''}, "AUTO_DECISION", False, "fp", "HTTP response body, not a decision record")

# ---------------------------------------------------------------- CORS_WILDCARD
case("co_pos", {"app.py": '''from fastapi.middleware.cors import CORSMiddleware
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True)
'''}, "CORS_WILDCARD", True, "pos", "FastAPI wildcard origin with credentials")
case("co_neg", {"app.py": '''from fastapi.middleware.cors import CORSMiddleware
app.add_middleware(CORSMiddleware, allow_origins=["https://app.example.com"])
'''}, "CORS_WILDCARD", False, "neg", "explicit origin")
case("co_ev_variable", {"app.py": '''ORIGINS = ["*"]
app.add_middleware(CORSMiddleware, allow_origins=ORIGINS)
'''}, "CORS_WILDCARD", True, "evasion", "wildcard held in a variable")
case("co_ev_express", {"app.js": '''const app = require("express")();
app.use(cors({ origin: "*" }));
'''}, "CORS_WILDCARD", True, "evasion", "Express cors wildcard")

# ---------------------------------------------------------------- SENSITIVE_DATA
case("sd_pos_pdf", {"customer_passport.pdf": None},
     "SENSITIVE_DATA", True, "pos", "sensitive filename + document extension")
case("sd_fp_template", {"passport_template.png": None},
     "SENSITIVE_DATA", False, "fp", "template asset, no personal data")
case("sd_ev_csv", {"customer_export.csv": "name,email\nAsha,asha@example.com\n"},
     "SENSITIVE_DATA", True, "evasion", "PII in an innocuously named CSV")
case("sd_ev_json", {"customer_records.json": '[{"email":"asha@example.com"}]\n'},
     "SENSITIVE_DATA", True, "evasion", "PII in JSON (categorised as IaC, never name-checked)")
case("sd_fp_1040", {"report_1040.pdf": None},
     "SENSITIVE_DATA", False, "fp", "tax-form digits in an unrelated filename")

# ---------------------------------------------------------------- UNSAFE_DESERIALIZE
case("ud_pos_pickle", {"load.py": '''import pickle
def load(data):
    return pickle.loads(data)
'''}, "UNSAFE_DESERIALIZE", True, "pos", "pickle.loads")
case("ud_neg_safe", {"load.py": '''import yaml
def load(s):
    return yaml.safe_load(s)
'''}, "UNSAFE_DESERIALIZE", False, "neg", "safe loader")
case("ud_ev_dill", {"load.py": '''import dill
def load(data):
    return dill.loads(data)
'''}, "UNSAFE_DESERIALIZE", True, "evasion", "dill.loads outside the pattern list")
case("ud_ev_eval_req", {"run.py": '''def run(req):
    return eval(req.body.code)
'''}, "UNSAFE_DESERIALIZE", True, "evasion", "eval over framework request object")
case("ud_neg_eval_const", {"calc.py": '''def calc():
    return eval("1 + 1")
'''}, "UNSAFE_DESERIALIZE", False, "neg", "eval of a constant")
case("ud_ev_new_function", {"run.js": '''function run(userInput) {
  return new Function(userInput)();
}
'''}, "UNSAFE_DESERIALIZE", True, "evasion", "new Function (JS dynamic execution)")

# ---------------------------------------------------------------- ERROR_LEAKAGE
case("el_pos_httpexception", {"api.py": '''from fastapi import HTTPException
def fail(e):
    raise HTTPException(status_code=500, detail=str(e))
'''}, "ERROR_LEAKAGE", True, "pos", "exception detail in HTTP response")
case("el_neg_log_only", {"api.py": '''import logging
def fail(e):
    logging.error(str(e))
'''}, "ERROR_LEAKAGE", False, "neg", "server-side logging only")
case("el_ev_dot_message", {"api.js": '''function fail(res, e) {
  return res.status(500).json({ error: e.message });
}
'''}, "ERROR_LEAKAGE", True, "evasion", "e.message instead of err.message")
case("el_ev_traceback", {"api.py": '''from flask import jsonify
import traceback
def fail(e):
    return jsonify({"error": traceback.format_exc()})
'''}, "ERROR_LEAKAGE", True, "evasion", "traceback.format_exc() in a response")
case("el_fp_server_log", {"api.js": '''const logger = require("./logger");
function handler(req, res, err) {
  logger.error("failed: %s", err.message);
  return res.json({ ok: true });
}
'''}, "ERROR_LEAKAGE", False, "fp", "err.message logged server-side; file also builds a response")

# ---------------------------------------------------------------- SAFETY_BYPASS
case("sb_pos", {"agent.py": '''import logging

def purge(order_id, skip_validation):
    skip_validation = True
    if not human_approval(order_id):
        raise PermissionError()
    logging.info("purging")
    db.delete(order_id)
'''}, "SAFETY_BYPASS", True, "pos", "validation flag disabled next to an action")
case("sb_neg_false", {"agent.py": '''import logging

def purge(order_id, skip_validation):
    skip_validation = False
    if not human_approval(order_id):
        raise PermissionError()
    logging.info("purging")
    db.delete(order_id)
'''}, "SAFETY_BYPASS", False, "neg", "flag left enabled")
case("sb_ev_env_flag", {"agent.py": '''import os, logging

def purge(order_id):
    os.environ["SKIP_VALIDATION"] = "1"
    if not human_approval(order_id):
        raise PermissionError()
    logging.info("purging")
    db.delete(order_id)
'''}, "SAFETY_BYPASS", True, "evasion", "bypass expressed as an environment variable")
case("sb_fp_validated_var", {"agent.py": '''import logging

def purge(order_id, validated):
    validated = False
    if not human_approval(order_id):
        raise PermissionError()
    logging.info("purging")
    db.delete(order_id)
'''}, "SAFETY_BYPASS", False, "fp", "a result variable that merely begins with 'validat'")

# ---------------------------------------------------------------- framework layer
case("fw_langchain_py", {"tools.py": '''from langchain.tools import tool

@tool
def search(q):
    logger.info("searching")
    db.delete(q)
'''}, "framework", True, "framework", "LangChain @tool", "framework")
case("fw_crewai_py", {"crew.py": '''from crewai import Agent
support = Agent(role="ops", tools=[delete_tool])
def run(q):
    logger.info("running")
    db.delete(q)
'''}, "framework", True, "framework", "CrewAI tools=[...]", "framework")
case("fw_autogen_py", {"group.py": '''def delete(q):
    logger.info("deleting")
    db.delete(q)
assistant = AssistantAgent("a", function_map={"delete": delete})
'''}, "framework", True, "framework", "AutoGen function_map", "framework")
case("fw_openai_schema_py", {"schema.py": '''TOOLS = [{"type": "function", "function": {"name": "delete"}}]
def run(q):
    logger.info("running")
    db.delete(q)
'''}, "framework", True, "framework", "OpenAI function schema", "framework")
case("fw_langchain_js", {"tools.js": '''import { tool } from "langchain";
const removeTool = tool(async ({ id }) => db.delete(id), { name: "delete" });
'''}, "framework", True, "framework", "LangChain JS tool()", "framework")
case("fw_langgraph_py", {"graph.py": '''from langgraph.prebuilt import ToolNode
def run(q):
    logger.info("running")
    db.delete(q)
node = ToolNode(tools)
'''}, "framework", True, "framework", "LangGraph ToolNode (not detected today)", "framework")
case("fw_openai_agents_py", {"sdk.py": '''from agents import function_tool

@function_tool
def remove(q):
    logger.info("removing")
    db.delete(q)
'''}, "framework", True, "framework", "OpenAI Agents SDK @function_tool (not detected today)", "framework")
case("fw_anthropic_py", {"claude.py": '''TOOLS = [{"name": "delete", "description": "delete", "input_schema": {"type": "object"}}]
def run(q):
    logger.info("running")
    db.delete(q)
'''}, "framework", True, "framework", "Anthropic tool-use schema (not detected today)", "framework")
case("fw_mcp_py", {"server.py": '''from mcp.server import Server
server = Server("ops")
@server.tool()
def remove(q):
    logger.info("removing")
    db.delete(q)
'''}, "framework", True, "framework", "MCP server @server.tool() (not detected today)", "framework")
case("fw_semantic_kernel_py", {"sk.py": '''from semantic_kernel import Kernel
kernel = Kernel()
kernel.add_function("delete_plugin", function=remove)
def run(q):
    logger.info("running")
    db.delete(q)
'''}, "framework", True, "framework", "Semantic Kernel add_function (not detected today)", "framework")
case("fw_llamaindex_py", {"llama.py": '''from llama_index.core.tools import FunctionTool
remove_tool = FunctionTool.from_defaults(fn=remove)
def run(q):
    logger.info("running")
    db.delete(q)
'''}, "framework", True, "framework", "LlamaIndex FunctionTool (not detected today)", "framework")
case("fw_pydantic_ai_py", {"pyd.py": '''from pydantic_ai import Agent
agent = Agent("openai:gpt-4o")
@agent.tool
def remove(q):
    logger.info("removing")
    db.delete(q)
'''}, "framework", True, "framework", "Pydantic AI @agent.tool (not detected today)", "framework")


def main():
    if os.path.isdir(CASES):
        shutil.rmtree(CASES)
    os.makedirs(CASES)
    manifest = []
    for c in cases:
        d = os.path.join(CASES, c["name"])
        os.makedirs(d)
        for fname, content in c["files"].items():
            p = os.path.join(d, fname)
            os.makedirs(os.path.dirname(p), exist_ok=True) if os.path.dirname(p) != d else None
            with open(p, "w", encoding="utf-8", newline="\n") as f:
                f.write(content or "")
        manifest.append(c)
    # cases that need a Python-unavailable probe are handled separately by
    # audit/run.js (documented in the report), not stored here.
    with open(os.path.join(HERE, "corpus", "manifest.json"), "w", encoding="utf-8", newline="\n") as f:
        json.dump(manifest, f, indent=2)
    print(f"wrote {len(manifest)} cases to {CASES}")


if __name__ == "__main__":
    main()
