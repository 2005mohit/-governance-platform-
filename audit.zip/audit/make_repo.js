const fs = require("fs");
const path = require("path");
const n = parseInt(process.argv[2] || "5000", 10);
const d = path.join(process.env.TEMP || "/tmp", "opencode", "repo" + n);
fs.rmSync(d, { recursive: true, force: true });
for (let i = 0; i < n; i++) {
  const sub = path.join(d, "pkg" + (i % 50), "src");
  fs.mkdirSync(sub, { recursive: true });
  fs.writeFileSync(
    path.join(sub, "f" + i + ".py"),
    "import logging\n\n# module " + i + "\nVALUE = " + i + "\n"
  );
}
console.log(d);
