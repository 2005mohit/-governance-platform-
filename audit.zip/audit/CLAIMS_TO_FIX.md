# Claims to fix

Every row is a public statement that is false, unverifiable, or materially
misleading as shipped. "Evidence" is the code or command that contradicts it.
"Replacement" is wording that is true today, so the fix does not depend on new
work.

Priority: **P0** = remove before any external user sees it; **P1** = next
release; **P2** = docs cleanup.

## 1. README

| # | Claim (verbatim / location) | Reality | Evidence | Replacement | Pri |
|---|---|---|---|---|---|
| C-01 | "using `argparse` for command parsing" — `README.md:2`, table row `:14` | Parsing is hand-rolled; no `argparse` dependency exists (it is a Python library) | `src/cli.js:12–37`; `package.json` dependencies = `js-yaml` only | "a small hand-rolled argument parser" | P1 |
| C-02 | "rules/ (YAML files) … (EU AI Act, India framework)" — `README.md:21` | Only `eu_ai_act.yaml` + `high_risk_actions.yaml` ship; there is no India pack | `Get-ChildItem rules`; paper calls India "future work" | "EU AI Act rule pack (India pack planned, not shipped)" | P0 |
| C-03 | "Scope and limits" lists 5 rules — `README.md:62–66` | 12 rules ship | `rules/eu_ai_act.yaml` ids: 12 | List all 12, or generate the list from the pack | P0 |
| C-04 | "Report is written to `./ai-risk-snapshot-report/` … **outside** the scanned directory by default" — `README.md:53–55` | Default is `path.join(process.cwd(), "ai-risk-snapshot-report")`, which is inside when scanning the cwd | `src/cli.js:57` | "written to `./ai-risk-snapshot-report/` in the current working directory (add it to `.gitignore`)" | P1 |
| C-05 | "pluggable, YAML-based rule engine" — `README.md:2`, `:15` | Rules are editable but the path is hard-coded; there is no `--pack`/config | `src/cli.js:124` | "an editable YAML rule pack" until `--pack` ships | P1 |
| C-06 | "Never executes your code, never modifies your files, never makes a network call" — `README.md:33–35` | **True** (verified). Keep. | `src/*.js` imports; PWNED test | No change | — |
| C-07 | "It is a **preliminary heuristic scan**, not a certified audit" — `README.md:6–7` | **True**. Keep and strengthen with applicability. | `src/reporter.js:59–63` | Add: "It does not determine whether your system is high-risk under Annex I/III." | P0 |

## 2. Project Overview

| # | Claim | Reality | Evidence | Replacement | Pri |
|---|---|---|---|---|---|
| C-08 | "Existing compliance tools … check for a single framework and only inspect static code" — `Project Overview.md:3` | Semgrep/Checkov/Bandit are framework-agnostic; garak/promptfoo are dynamic | `COMPETITOR_MATRIX.md` §1 | "Most free tools are general security scanners; few map findings to AI-governance review questions." | P1 |
| C-09 | "checks both code-level and dataset-level compliance risk against more than one jurisdiction's rules in a single scan" — `:3` | One jurisdiction (EU); no dataset inspection | `rules/`; `src/scanner.js:271–277` | Remove "dataset-level" and "more than one jurisdiction" until shipped | P0 |
| C-10 | "Support **static code/dependency scanning**" — `:8` | No dependency scanning exists | no manifest/SCA code in `src/` | "static code and configuration scanning" | P1 |
| C-11 | "AST-based parsing (`@babel/parser` or `tree-sitter`)" — `:28` | The only AST is Python's stdlib `ast`, used by one helper for two rules | `src/ast_check.py`; no babel/tree-sitter dependency | "Python AST helper for guard detection; regex proximity for other languages" | P0 |
| C-12 | "All processing happens on the user's machine — no code or data is uploaded anywhere" — `:19` | **True** for the scanner; keep, but note report.json contains code snippets if the user sends it | `src/scanner.js:705–707`; `src/agreement.js:29–33` | Add the snippet caveat to the terms/README | P2 |

## 3. Report output

| # | Claim | Reality | Evidence | Replacement | Pri |
|---|---|---|---|---|---|
| C-13 | "Where we looked - four risk areas the EU AI Act covers" - `src/reporter.js:386` | The pack spans 5 articles and 12 rules; "areas" is derived from finding count, not coverage; the Act covers far more | `src/reporter.js:167–172`, `:174–199`; `RULE_VALIDATION.md` | "Where we looked — the 12 checks in this scan" + a coverage table with "not checked" | P0 |
| C-14 | Each card states an article as if applicable — `src/reporter.js` card template | Arts. 9/12/14/15 are high-risk-only; no classification, role, or date is shown | `src/reporter.js:47–63`, `:406–409` | Prefix findings: "Indicator for review — not a compliance finding. Art. X applies to high-risk systems." | P0 |
| C-15 | "ast-confirmed" in JSON/HTML | The AST can be absent (silent fallback) and is intra-function only | `src/scanner.js:561–569`; `src/ast_check.py:168–208`; `nh_ev_helper_guard` | Emit `method: "proximity-heuristic"` when Python is absent; rename to `structure-checked (same function)` | P0 |
| C-16 | Score + band — `src/reporter.js:24–45` | 75 and 25 both say "Severe gap"; 85 with one HIGH says "Elevated gap"; 10 with six HIGHs is milder than 0 with 20 MEDIUMs | §4 #9 of `AUDIT_REPORT.md` | Publish severity and score separately, or fix band thresholds | P1 |
| C-17 | "This is not a certified compliance audit" — `:406` | True, but insufficient: no applicability/role/date/coverage statement | `:406–409` | Add an "Applicability and limits" block | P0 |
| C-18 | CTA: "reach out with report.json if you'd like a full audit" — `src/cli.js:154`; `:397` | **Accurate as a service offer.** Do not remove. Nuance: report.json contains code snippets | `src/scanner.js:705–707`; terms `src/agreement.js:29–33` | Optionally add: "report.json contains code excerpts; review before sharing." | P2 |

## 4. Research paper

| # | Claim | Reality | Evidence | Replacement | Pri |
|---|---|---|---|---|---|
| C-19 | "one deliberately constructed positive fixture and one deliberately constructed negative fixture for each of nine rules" — `RESEARCH_PAPER_REVISED.docx`, RQ1 | True for the paper, but the pack ships 12; three rules have no fixture-level validation | `rules/eu_ai_act.yaml` (12 ids); paper text | Keep "nine"; add "the three later rules … are not covered by this benchmark" | P1 |
| C-20 | "1.00 precision and 0.78 recall" — abstract, RQ1 | True *fixture-level*; not field precision | paper §RQ1 says so; this audit's corpus: 0.548 / 0.436 | Always attach "fixture-level, 9 rules, 18 cases" and cite the field result | P1 |
| C-21 | Table 2 says `SENSITIVE_DATA` → "Art. 10 data governance; GDPR" | Shipped YAML says Art. 9 & 15 | `rules/eu_ai_act.yaml:286` vs paper Table 2 | Change the YAML to Art. 10 / GDPR, or change the paper to match the code — do not leave the contradiction | P0 |
| C-22 | Table 2 lists 9 indicators | Pack has 12 (missing UNSAFE_DESERIALIZE, ERROR_LEAKAGE, SAFETY_BYPASS) | `rules/eu_ai_act.yaml` | Add the three rows with "not benchmarked" | P1 |
| C-23 | "Articles 9, 12, 14, and 15 apply to high-risk systems only … The CLI does not determine whether a target is high-risk" — §2 | True, and **not in the output** | `src/reporter.js:406–409` | Move this sentence into every report | P0 |
| C-24 | "An India-specific YAML pack … remains future work" — §2 | True. Consistent with code, inconsistent with README C-02 | `rules/` | Align README to the paper | P0 |

## 5. Terms / consent

| # | Claim | Reality | Evidence | Replacement | Pri |
|---|---|---|---|---|---|
| C-25 | "It does not execute your code, modify any file, or install anything beyond its own dependencies" — `src/agreement.js:12–14` | True (no code execution; writes only the report/consent log) | PWNED test; `src/reporter.js:465–466` | No change | — |
| C-26 | "The report redacts common personal-data patterns … before they're written to any output file" — `src/agreement.js:26–28` | True for the four patterns; but source-code snippets and non-PII data remain, and secrets are masked separately | `src/utils.js:10–40`, `:34–40` | Add: "Code excerpts remain in the report; redaction covers the listed patterns only." | P1 |
| C-27 | "We may reuse anonymised, non-identifying *patterns*" — `src/agreement.js:29–33` | No telemetry exists, so this is a permission, not a practice; fine as drafted | no network code | No change | — |

## 6. Version / metadata

| # | Claim | Reality | Evidence | Replacement | Pri |
|---|---|---|---|---|---|
| C-28 | `engines.node: ">=16.0.0"` — `package.json` | Untested on 16/18/20/22 | only Node 24.19.0 available | Add CI matrix or raise to a tested floor | P1 |
| C-29 | `files: ["src/","rules/","README.md","LICENSE"]` — `package.json` | Verified: 11 files, `audit/` excluded, `ast_check.py` ships | `npm pack --dry-run` | No change | — |
| C-30 | MIT — `LICENSE`, `package.json` | Verified | file present | No change | — |

## 7. The one-line fix that buys the most credibility

Add this block to `report.json` and the top of `report.html`:

> **What this is.** A local pattern scan of source files. It does not determine
> whether your system is high-risk under Annex I/III, does not assess
> compliance, and does not replace legal review. Article references are
> review prompts. Each finding shows the detection method; `proximity-heuristic`
> findings are weaker than `structure-checked` ones. High-risk obligations in
> Arts. 9/12/14/15 apply from 2 Dec 2027 (Annex III) / 2 Aug 2028 (Annex I).

That single block resolves C-13, C-14, C-17, C-23 and most of the credibility
gap without touching the detector. Do it before anything else.
