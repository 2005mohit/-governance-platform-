#!/usr/bin/env node
// Reproducible corpus harness for the audit. Scans every case in isolation,
// compares the observed rule ids with the manifest's stated-intent expectation,
// and writes audit/reports/metrics.json. Run: node audit/run.js
const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

const ROOT = path.resolve(__dirname, "..");
const CASES = path.join(__dirname, "corpus", "cases");
const MANIFEST = path.join(__dirname, "corpus", "manifest.json");
const OUTDIR = path.join(__dirname, "scratch", "mrun");
const REPORT = path.join(__dirname, "reports", "metrics.json");
const CLI = path.join(ROOT, "src", "cli.js");

fs.mkdirSync(OUTDIR, { recursive: true });
const manifest = JSON.parse(fs.readFileSync(MANIFEST, "utf8"));

function runCase(name) {
  const dir = path.join(CASES, name);
  const res = spawnSync(process.execPath, [CLI, dir, "--yes", "-o", OUTDIR], {
    encoding: "utf8",
    timeout: 180000,
  });
  const rp = path.join(OUTDIR, "report.json");
  if (!fs.existsSync(rp)) {
    return { error: `no report (status ${res.status})`, findings: [] };
  }
  const rep = JSON.parse(fs.readFileSync(rp, "utf8"));
  return { findings: rep.findings || [], score: rep.score, skipped: res.status };
}

const per = {};
const rows = [];
const frameworks = [];

for (const c of manifest) {
  const out = runCase(c.name);
  const found = [...new Set(out.findings.map((f) => f.id))];

  if (c.type === "framework") {
    const f = out.findings.find((x) => x.id === "NO_HUMAN_LOOP") || out.findings[0];
    frameworks.push({
      name: c.name,
      expected: "agent-tool",
      observed: f ? f.toolExposure : null,
      signalPresent: !!(f && f.toolExposure === "agent-tool"),
      note: c.note,
    });
    continue;
  }

  const target = c.target;
  if (!per[target]) per[target] = { tp: 0, fp: 0, fn: 0, tn: 0, cases: [] };
  const pred = found.includes(target);
  const exp = !!c.expect;
  if (exp && pred) per[target].tp++;
  else if (exp && !pred) per[target].fn++;
  else if (!exp && pred) per[target].fp++;
  else per[target].tn++;

  const hit = out.findings.find((f) => f.id === target);
  per[target].cases.push({
    name: c.name,
    kind: c.kind,
    expect: exp,
    predicted: pred,
    found,
    method: hit ? hit.method : null,
    exposure: hit ? hit.toolExposure : null,
    note: c.note,
  });
  rows.push({
    name: c.name,
    target,
    kind: c.kind,
    expect: exp,
    predicted: pred,
    found,
    method: hit ? hit.method : null,
    exposure: hit ? hit.toolExposure : null,
  });
}

const summary = {};
for (const [rule, m] of Object.entries(per)) {
  const p = m.tp + m.fp;
  const r = m.tp + m.fn;
  summary[rule] = {
    tp: m.tp,
    fp: m.fp,
    fn: m.fn,
    tn: m.tn,
    precision: p ? +(m.tp / p).toFixed(3) : null,
    recall: r ? +(m.tp / r).toFixed(3) : null,
    cases: m.cases,
  };
}

const out = {
  generatedBy: "audit/run.js",
  note: "Expressions are stated-intent expectations written before running the scanner. Small, purposive corpus; treat rates as directional, not statistically representative.",
  totals: rows.reduce(
    (a, r) => {
      if (r.expect && r.predicted) a.tp++;
      else if (r.expect && !r.predicted) a.fn++;
      else if (!r.expect && r.predicted) a.fp++;
      else a.tn++;
      return a;
    },
    { tp: 0, fp: 0, fn: 0, tn: 0 }
  ),
  rules: summary,
  frameworks,
  rows,
};
fs.writeFileSync(REPORT, JSON.stringify(out, null, 2));

const pad = (s, n) => String(s).padEnd(n);
console.log(pad("RULE", 22), pad("TP", 4), pad("FP", 4), pad("FN", 4), pad("TN", 4), pad("PREC", 7), "RECALL");
for (const [rule, s] of Object.entries(summary)) {
  console.log(pad(rule, 22), pad(s.tp, 4), pad(s.fp, 4), pad(s.fn, 4), pad(s.tn, 4), pad(s.precision, 7), s.recall);
}
console.log("\nFRAMEWORK DETECTION");
for (const f of frameworks) {
  console.log(pad(f.name, 26), f.signalPresent ? "DETECTED" : "MISSED", "  ", f.note);
}
console.log(`\nwrote ${REPORT}`);
