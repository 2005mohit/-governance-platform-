# Rule validation — legal mapping vs. measured behaviour

Audit date: 2026-11-12. Tool under test: `ai-risk-snapshot` 1.1.0 (`package.json`).
All metrics in this file come from `audit/reports/metrics.json`, produced by
`node audit/run.js` over the 84-case corpus in `audit/corpus/cases/` (expectations
were written from each rule's stated intent before the scanner was run).

Legal text source: `artificialintelligenceact.eu` article pages, saved under
`audit/scratch/art*.txt` (EUR-Lex returned HTTP 202 with an empty body, so the
official OJ text could not be scraped directly; article numbering and wording
were cross-checked against the saved pages). Quotes are kept under 15 words.

## Rating scale used here

| Rating | Meaning |
| --- | --- |
| **Strong** | The code observable is a direct proxy for a specific legal element, on the same actor, with little ambiguity. |
| **Weak** | The observable is a relevant risk indicator, but it does not establish the legal element. It is evidence for a human to investigate. |
| **Wrong** | The rule names an article whose legal test the observable cannot speak to, or attributes a provider duty to a deployer (or vice versa). |

No rule in the shipped pack rates **Strong**. Treat that as the headline result:
the pack is an indicator checklist with article labels, not a compliance test.

## The 12 rules

| # | Rule | Shipped mapping (`rules/eu_ai_act.yaml`) | Rating | Anchor quote | Precision | Recall | Verdict |
|---|---|---|---|---|---|---|---|
| 1 | `IDENTITY_KEY` | Art. 15(5) (line 5) | Weak | "resilient against attempts by unauthorised third parties to alter their use" (15(5)) | 1.00 | 0.40 | Keep detector; soften claim; extend patterns |
| 2 | `IAM_WILDCARD` | Art. 15(5) & Art. 9 (line 37) | Weak / **Wrong** for Art. 9 | "A risk management system shall be established … in relation to high-risk AI systems" (9(1)) | 1.00 | 0.33 | Keep detector; delete Art. 9 mapping |
| 3 | `NO_HUMAN_LOOP` | Art. 14 (line 92) | Weak | "effectively overseen by natural persons" (14(1)) | 0.44 | 0.57 | Rework (highest-value, highest-FP rule) |
| 4 | `NO_LOGGING` | Art. 12 (line 130) | Weak | "automatic recording of events (logs) over the lifetime" (12(1)) | 0.50 | 1.00 | Keep, rework to system level |
| 5 | `NO_AI_DISCLOSURE` | Art. 50 (line 163) | **Wrong artifact** | "informed that they are interacting with an AI system" (50(1)) | 0.50 | 0.33 | Drop or redesign around user-facing UI |
| 6 | `HTTP_NO_AUTH` | Art. 15(5) (line 196) | Weak | "resilient against attempts by unauthorised third parties to alter their use" | 0.50 | 1.00* | Rework as project-level graph, or demote to AppSec |
| 7 | `AUTO_DECISION` | Art. 14 (line 225) | Weak | "override or reverse the output of the high-risk AI system" (14(4)) | 0.50 | 0.33 | Rework context gate, or drop |
| 8 | `CORS_WILDCARD` | Art. 15(5) (line 261) | Weak | "resilient against attempts by unauthorised third parties" | 1.00 | 0.33* | Keep as security hygiene, not an AI Act finding |
| 9 | `SENSITIVE_DATA` | Art. 9 & Art. 15 (line 286) | **Wrong** | "data governance and management practices" for training data (10(2)) | 0.33 | 0.33 | Rework to content-aware, re-map to Art. 10 / GDPR |
| 10 | `UNSAFE_DESERIALIZE` | Art. 15(5) (line 338) | Weak | "resilient against attempts by unauthorised third parties" | 1.00 | 0.25 | Keep; extend patterns; label as vulnerability indicator |
| 11 | `ERROR_LEAKAGE` | Art. 15(5) (line 373) | Weak | "resilient against attempts by unauthorised third parties" | 0.50 | 0.33 | Rework context window or drop |
| 12 | `SAFETY_BYPASS` | Art. 14 & Art. 9 (line 409) | Weak / **Wrong** for Art. 9 | "override or reverse the output" (14(4)) | 0.50 | 0.50 | Rework flag list; delete Art. 9 mapping |

`*` Recall of 1.00 on 1–3 positives only; not a meaningful estimate.

## Why each rating was given

### 1. `IDENTITY_KEY` — Weak
A hardcoded credential is a real security defect (`src/scanner.js:364`-adjacent
patterns; YAML lines 3–33). Art. 15(5) is about resilience to third-party
manipulation, so a leaked key is an indicator that the system *could* be
altered, not proof that the high-risk obligation was breached. Art. 15 also
binds **providers** ("shall be designed and developed"), while the CLI never
establishes which role the scanned repository plays.

Measured misses: `sk-proj-*` (current OpenAI project keys), concatenated keys,
and `github_pat_*` (fine-grained GitHub PATs). Verified by `id_ev_projkey`,
`id_ev_concat`, `id_ev_github_pat` in `metrics.json`.

### 2. `IAM_WILDCARD` — Weak for Art. 15(5), Wrong for Art. 9
Art. 9 requires a documented, continuously updated risk-management *process*.
A wildcard in an IaC policy says nothing about whether that process exists.
The paper itself already downgraded this mapping ("cf. Art. 9"), but the shipped
YAML still presents them as co-equal (line 37) and the HTML renders the string
verbatim. Measured misses: CloudFormation list form `Action: ["*"]`
(`iam_ev_list`) and service-level wildcard `s3:*` (`iam_ev_service`).

### 3. `NO_HUMAN_LOOP` — Weak, and the least reliable rule
Art. 14(1) requires design so that systems "can be effectively overseen by
natural persons", not the presence of a function named `human_approval`. The
detector's marker list is six hard-coded English identifiers
(`rules/eu_ai_act.yaml`, `approvalMarkers`), so any other approval idiom is a
false negative. Measured:

- FP: guard lives in a helper (`nh_ev_helper_guard`, still labelled
  `ast-confirmed`), JS class method (`nh_fp_js_class`), TS interface
  (`nh_fp_ts_interface`), `or` guard (`nh_neg_or`), guard inside `try`
  (`nh_neg_try`).
- FN: `db.remove(...)` synonym (`nh_ev_renamed`), destructive SQL in a string
  (`nh_ev_string_sql`), `getattr(db, "delete")(...)` (`nh_ev_dynamic`).

The `ast-confirmed` label is materially misleading here: `src/ast_check.py`
analyses only the enclosing function (`dominated_by_guard`, lines 168–208) and
treats `or` conservatively as ungated (lines 137–142). It cannot see a guard in
the callee, which is exactly the `nh_ev_helper_guard` case — still reported as
structurally confirmed.

### 4. `NO_LOGGING` — Weak
Art. 12(1) requires the *system* to allow automatic recording over its
lifetime. The rule instead asks whether a logging token appears within 15 lines
of a call. Measured 0/2 negatives correctly rejected in the opposite direction:
it flagged a caller whose callee logs (`nl_ev_callee_logging`) and missed a
custom audit sink (`nl_ev_custom_logger`). Recall 1.00 is an artefact of three
positives with no logging token anywhere.

### 5. `NO_AI_DISCLOSURE` — Wrong artifact
Art. 50(1) obliges providers to ensure users are "informed that they are
interacting with an AI system". That is a user-facing notice. The rule instead
reads the **system-prompt body** (`checkDisclosureLogic`, `src/scanner.js:631`)
and looks for phrases such as "i am an AI". Measured:

- FP: disclosure is in a user-facing constant while the internal prompt is
  clean (`nd_ev_ui_disclosure`).
- FN: internal marker "I am an AI" suppresses the finding even though no user
  sees it (`nd_ev_internal_marker`); prompt loaded from a file (`nd_ev_prompt_file`).

It also only sees the first prompt in a file and caps at 5 findings
(`maxFindings: 5`, line 192). Art. 50 is not high-risk-only, but the rule's
output does not say which actor (provider/deployer) it assumes.

### 6. `HTTP_NO_AUTH` — Weak
Auth in middleware or at `include_router` is invisible (`ha_ev_middleware` FP:
`main.py` enforces auth, `routes.py` is flagged). The rule is file-local, and
`ENDPOINT_AUTH` (`src/scanner.js:55`) is a small regex list. A route without a
visible decorator is not a route without auth. Art. 15(5) is also a provider
design duty; the scanned repo is more often a deployer.

### 7. `AUTO_DECISION` — Weak
Art. 14(4) gives overseers the ability to "override or reverse the output". A
literal `decision["status"] = "approved"` does not establish that no human
reviewed it; the assignment could be downstream of review. The rule only
matches four literal outcomes and a context word, so a computed `outcome`
variable (`ad_ev_variable`) or an enum (`ad_ev_enum`) is missed, while an HTTP
response body in a file containing "decision" is flagged (`ad_fp_js_response`).
`receiverCheck` is only applied for `.py` (`src/scanner.js:506`), so JS has no
receiver filtering.

### 8. `CORS_WILDCARD` — Weak
Wildcard CORS with credentials is a real security defect, but it is generic
AppSec, not an AI-specific Art. 15(5) indicator. One pattern
(`allow_origins`), so Express (`co_ev_express`) and variable-held origins
(`co_ev_variable`) are missed. Keep it only if the report labels it "security
hygiene" rather than "EU AI Act risk".

### 9. `SENSITIVE_DATA` — Wrong as shipped
Shipped YAML maps it to Art. 9 and Art. 15 (line 286). Art. 9 is the
risk-management process; Art. 10 is the data-governance article for training,
validation and testing data; the GDPR is the actual personal-data regime. The
paper (revised, Table 2) says "Art. 10 data governance; GDPR", so the shipped
output contradicts the paper.

Implementation is filename-only on **non-code, non-IaC** files
(`src/scanner.js:271–277`). Consequences, all measured:

- `customer_passport.pdf` → TP.
- `passport_template.png` → FP (no personal data).
- `report_1040.pdf` → FP (the `1040` regex hits an unrelated number).
- `customer_export.csv` → FN (CSV with emails under an innocuous name).
- `customer_records.json` → FN (`.json` is categorised as IaC at
  `src/scanner.js:227`, so it is never name-checked).

It cannot see PII in code, SQL, prompts, logs, or serialized stores.

### 10. `UNSAFE_DESERIALIZE` — Weak
`pickle.loads`, `torch.load` without `weights_only=True`, `yaml.load` without
`SafeLoader`, and `eval` over request data are genuine vulnerability classes.
Art. 15(5) is the closest anchor ("resilient against attempts by unauthorised
third parties to alter their use"), but the rule detects a *vulnerability
pattern*, not an Art. 15 breach. Missed: `dill.loads`, `eval(request.body.code)`,
`new Function(userInput)()`. Measured recall 0.25.

### 11. `ERROR_LEAKAGE` — Weak
`str(e)` in an HTTP error is a plausible information leak. But the detector
(`detail = str(`, `err.message`, `str(e)`) plus a file-level context list
(`HTTPException`, `jsonify`, `res.json`, …) is too loose: a server-side
`logger.error("failed: %s", err.message)` in a file that also builds a response
is flagged (`el_fp_server_log`). It matches `str(e)` in *any* logging call.
Art. 15(5) is a stretch; the clearer anchor is generic secure-error-handling.

### 12. `SAFETY_BYPASS` — Weak, with a concrete FP
Art. 14(4) oversight supports the anchor for a disabled approval/validation
flag. But the fourth bypass pattern is `\bvalidat(?:e|ion)\w*\s*[:=]\s*(?:False|false)\b`,
which matches an ordinary result variable `validated = False`
(`sb_fp_validated_var`). It also requires a taxonomy verb within 15 lines, so
`os.environ["SKIP_VALIDATION"] = "1"` is missed (`sb_ev_env_flag`). Mapping it
to Art. 9 repeats the Art. 9 error above.

## Cross-cutting legal findings

1. **Applicability is assumed, never established.** Arts. 9, 12, 14 and 15 apply
   only to high-risk systems (Art. 6 + Annex I/III). The CLI does not classify
   the target and does not say so in `report.json` or `report.html`; the only
   applicability statement is in the paper (`RESEARCH_PAPER_REVISED.docx`, §2)
   and in nothing the user receives. **VERIFIED** (`src/reporter.js:47–63`,
   `src/reporter.js:406–409`).
2. **Provider vs deployer is not modelled.** Art. 15/9/12/14 are primarily
   provider duties; Art. 26 is the deployer duty. The report attributes article
   numbers without saying which role it assumes. **VERIFIED.**
3. **Dates are not surfaced.** The high-risk obligations in the report apply from
   2 Dec 2027 (Annex III) / 2 Aug 2028 (Annex I), per Art. 113(c), yet the HTML
   presents findings as present-tense "Article 15" issues. **VERIFIED**
   (`audit/scratch/art12.txt` header; `src/reporter.js` has no date string).
4. **Art. 50 is not high-risk-only**, which makes `NO_AI_DISCLOSURE` the one rule
   whose applicability is broad — and it is the rule with the wrong artefact.
5. **`AUTO_DECISION`/`NO_HUMAN_LOOP` are classification-adjacent.** Whether an
   auto-approval is high-risk depends on Annex III use (creditworthiness,
   employment, essential services), which the tool never checks; the `# underwriting
   decision` comment in the corpus is enough to fire it.

## Net verdict on the rule pack

- 0 Strong, 9 Weak, 3 with at least one **Wrong** mapping.
- Aggregate corpus result: TP 17, FP 14, FN 22, TN 19 →
  precision 0.548, recall 0.436, F1 0.485.
- The paper's 1.00 / 0.78 is fixture-level and covers **9** of the 12 shipped
  rules. `UNSAFE_DESERIALIZE`, `ERROR_LEAKAGE` and `SAFETY_BYPASS` have no
  fixture-level validation in the paper.
- Recommendation: treat the pack as **"review prompts"**, not "article
  findings". Any external wording that implies compliance determination is
  unsupported by the code.
