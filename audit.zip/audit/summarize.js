const fs = require("fs");
const path = process.argv[2];
const d = JSON.parse(fs.readFileSync(path, "utf8"));
console.log(`file=${path}`);
console.log(`score=${d.score} band=${d.riskRating} files=${d.filesScanned} skipped=${d.filesSkipped} findings=${d.findings.length}`);
d.findings.forEach((f, i) => {
  console.log(`${i+1}. [${f.severity}] ${f.id} @ ${f.file}:${f.line} method=${f.method} exposure=${f.toolExposure}`);
  console.log(`     snippet=${JSON.stringify((f.snippet||"").slice(0,110))}`);
});
