import re, sys, html

def extract(path, label):
    s = open(path, encoding='utf-8', errors='ignore').read()
    # remove scripts/styles
    s = re.sub(r'(?is)<(script|style|nav|footer|header)[^>]*>.*?</\1>', ' ', s)
    # isolate the article body: from the main article title to the explorer link
    m = re.search(r'(?is)(<h1[^>]*>\s*Article\s+\d+.*?</h1>).*?(View in the full AI Act Explorer|Cookies on this website)', s)
    if m:
        s = m.group(0)
    # strip tags
    s = re.sub(r'(?s)<[^>]+>', ' ', s)
    s = html.unescape(s)
    s = re.sub(r'[ \t\r\f\v]+', ' ', s)
    s = re.sub(r'\n\s*\n+', '\n', s)
    # collapse the annotation noise: keep lines starting with numbering or letters
    lines = [l.strip() for l in s.split('\n') if l.strip()]
    print(f"===== {label} =====")
    for l in lines:
        # skip huge annotation blobs
        if len(l) > 900:
            l = l[:900] + ' ...[truncated]'
        print(l)

if __name__ == '__main__':
    import io
    out = io.StringIO()
    _stdout = sys.stdout
    sys.stdout = out
    try:
        extract(sys.argv[1], sys.argv[2])
    finally:
        sys.stdout = _stdout
    with open(sys.argv[3], 'w', encoding='utf-8') as f:
        f.write(out.getvalue())
