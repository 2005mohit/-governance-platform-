#!/usr/bin/env node
// Rule-schema robustness probes. Constructs Scanner directly with malformed
// packs placed under audit/scratch/ (no existing file is modified).
const fs = require("fs");
const path = require("path");
const Scanner = require("../src/scanner");

const SCRATCH = path.join(__dirname, "scratch", "schema");
fs.mkdirSync(SCRATCH, { recursive: true });
const target = path.join(__dirname, "scratch", "asttests", "noexec");

const packs = {
  invalid_regex: `rules:\n  - id: BAD\n    severity: HIGH\n    patterns: ["("]\n`,
  missing_rules_key: `not_rules:\n  - id: X\n`,
  no_detection: `rules:\n  - id: EMPTY\n    severity: HIGH\n    fileTypes: ["code"]\n`,
  bad_severity: `rules:\n  - id: ODD\n    severity: SUPER\n    patterns: ["db\\\\.delete\\\\s*\\\\("]\n`,
  dangling_ref: `rules:\n  - id: REF\n    severity: HIGH\n    logic: high_risk_action_without_approval\n    actionsRef: does_not_exist\n`,
  non_list_rules: `rules: "nope"\n`,
  alias_bomb: `rules:\n  - id: BOMB\n    severity: LOW\n    patterns: ["x"]\n    extra: &a ["aaaaaaaa","aaaaaaaa","aaaaaaaa","aaaaaaaa","aaaaaaaa","aaaaaaaa","aaaaaaaa","aaaaaaaa"]\n    more: [*a,*a,*a,*a,*a,*a,*a,*a]\n`,
};

(async () => {
  for (const [name, body] of Object.entries(packs)) {
    const p = path.join(SCRATCH, `${name}.yaml`);
    fs.writeFileSync(p, body);
    const t0 = Date.now();
    try {
      const s = new Scanner(p, target);
      const findings = await s.scan();
      console.log(`${name}: NO ERROR, findings=${findings.length}, ms=${Date.now() - t0}`);
    } catch (e) {
      console.log(`${name}: THREW ${e.constructor.name}: ${String(e.message).split("\n")[0]}`);
    }
  }
})();
