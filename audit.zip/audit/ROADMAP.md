# Roadmap and acceptance criteria

Sequenced by **credibility per unit of work**, not by feature appeal. Every item
names the finding ids it closes (`audit/FINDINGS.csv`) and a test that proves it.

Definition of done for every item: code + test + docs + report change, and the
baseline fixtures still produce 6 / 4 / 0 / 2 findings.

---

## Phase 0 — 0 to 2 weeks: stop overclaiming

Goal: a report that a lawyer cannot call misleading, without changing the
detector. This is the highest-value work in the whole plan.

| # | Work | Closes | Acceptance test |
|---|---|---|---|
| 0.1 | Add an **Applicability block** to `report.json` and the top of `report.html`: not a compliance determination; high-risk status not assessed; Arts. 9/12/14/15 apply only to high-risk systems; role (provider/deployer) not determined; dates 2 Dec 2027 / 2 Aug 2028; detection method per finding | F-21, C-13, C-14, C-17, C-23 | Snapshot test asserts the block is present in both outputs; grep for "compliance" returns only the negated sentence |
| 0.2 | Replace "Where we looked — four risk areas the EU AI Act covers" with "The 12 checks in this scan" and a rule/article coverage table | F-20, C-13 | HTML contains 12 rule ids and an explicit "not checked" list |
| 0.3 | Fix the three wrong mappings: `SENSITIVE_DATA` → Art. 10 / GDPR; remove Art. 9 from `IAM_WILDCARD` and `SAFETY_BYPASS` | F-08, F-10, F-11, C-21 | Unit test asserts `finding.references` exact values; no finding string contains "Article 9" except the SDF/human-review pack |
| 0.4 | Correct README and Project Overview: `argparse`, India pack, 5 vs 12 rules, output location, "pluggable", AST claim | F-43…F-47, C-01…C-05, C-08…C-11 | A docs test greps for banned strings (`argparse`, "India framework", "@babel/parser", "tree-sitter") and fails |
| 0.5 | Add `--fail-on <severity>` and non-zero exit codes; default remains 0 | F-27, F-30 | `test-baseline --fail-on HIGH` exits 1; without the flag exits 0 |
| 0.6 | Warn when Python is absent or the AST returns null; add `astAvailable` and `method` to report meta | F-01, C-15 | PATH=node-only run prints one warning and sets `astAvailable:false`; HTML shows "not structure-checked" |
| 0.7 | Fix `SAFETY_BYPASS` `validated = False` FP; add JS/TS definition filtering (class method, interface, arrow prop) | F-03, F-12 (part), F-13 | New fixtures `sb_neg_validated_result`, `nh_fp_js_method`, `nh_fp_ts_iface` pass |
| 0.8 | Bump `js-yaml` to a patched version; add `npm audit --audit-level=high` to CI | F-36 | `npm audit` returns 0 high; lockfile pinned |
| 0.9 | Add a minimal test harness: unit tests for scoring/redaction/parser + the 4 baseline fixtures | F-50 | `npm test` runs and fails if the 6-finding baseline changes |
| 0.10 | Make `--output` refuse to overwrite an existing report pair without `--force` | F-35 | Second run without `--force` exits non-zero with a clear message |

**Exit criterion for Phase 0:** a new user reading only the report knows (a) it
is not a compliance assessment, (b) which findings are structure-checked, (c)
what was not checked, and (d) which articles are high-risk-only. Nothing in the
report contradicts the paper.

---

## Phase 1 — 1 to 2 months: make it usable in a real workflow

Goal: a team can add it to CI, triage without noise, and extend it without
editing source.

| # | Work | Closes | Acceptance test |
|---|---|---|---|
| 1.1 | Rule-pack schema + validation (ids, severity enum, detector fields, regex compile, references); fail with file/rule/field | F-39, F-40, F-41, F-42 | `audit/schema_test.js` cases all produce actionable messages; severity `SUPER` is rejected |
| 1.2 | Add `schemaVersion`, per-finding stable fingerprint, and a published JSON schema | F-32 | Same finding in two runs has the same fingerprint; schema validates the report |
| 1.3 | SARIF 2.1.0 output (`--format sarif`) with rule ids, physical locations, and severity mapping | F-28 | GitHub code-scanning ingest test; `sarif` validates against the 2.1.0 schema |
| 1.4 | Baseline + inline suppression: `--baseline`, `# ai-risk-ignore: RULE reason`, `# ai-risk-ignore-file` | F-29 | Suppressed finding disappears; a new finding still fails the gate |
| 1.5 | Config file (`.ai-risk.yaml`) + repeatable `--pack`; remove the hard-coded path | F-31 | `--pack rules/india_dpdp.yaml` runs; unknown pack exits 2 with a message |
| 1.6 | HTTP auth: project-level route table + middleware/`include_router`/`app.use` resolution; do not fire when auth is applied at mount | F-14 | `ha_ev_middleware` becomes TN; `ha_pos` stays TP |
| 1.7 | Human-oversight: interprocedural guard detection, or demote the label to `same-function check` and stop calling it `ast-confirmed` when the callee is unknown | F-02, F-05 | `nh_ev_helper_guard` no longer claims confirmation; `nh_neg_or`/`nh_neg_try` become TN |
| 1.8 | Tool exposure per call site/function, not per file | F-19 | A file with `@tool` at the top and an unrelated `db.delete` in another function gets `general-code` for the latter |
| 1.9 | Extend framework signals: LangGraph, OpenAI Agents SDK, Anthropic, MCP, Semantic Kernel, LlamaIndex, Pydantic AI | F-18 | The 7 `fw_*` MISSED cases become DETECTED; no new FP on 20 ordinary files |
| 1.10 | Performance: index candidates by line/function, batch AST calls, cap per-file candidates; suppress per-file stderr when not a TTY | F-37, F-38 | 20k `db.delete()` file < 10 s; 50k files < 120 s; CI log ≤ 20 lines |
| 1.11 | Expand `SENSITIVE_DATA` to content-aware PII (code + data files), exclude templates, re-map to Art. 10/GDPR | F-07 | `sd_ev_csv`, `sd_ev_json` become TP; `sd_fp_template`, `sd_fp_1040` become TN |
| 1.12 | Report: confidence per finding, truncation counts, coverage matrix, remediation priority | F-24, F-25, F-26, F-22 | HTML shows method/confidence for all 12 rules; score/band table matches the documented policy |
| 1.13 | India pack 0.1 (opt-in): security safeguards, breach notify, CERT-In clocks, Aadhaar/PAN with checksums | F-44 | `audit/corpus-india` precision ≥ 0.85 for validated PII; zero raw PII in output |

**Exit criterion for Phase 1:** a design partner can run it in GitHub Actions,
suppress known issues, fail the build on new HIGHs, and get SARIF annotations.
The India pack is opt-in and labelled experimental.

---

## Phase 2 — 3 to 6 months: earn the legal and empirical claims

Goal: replace "we think this maps to Article X" with measured performance and
counsel-reviewed mappings.

| # | Work | Closes | Acceptance test |
|---|---|---|---|
| 2.1 | Counsel review of the EU and India mappings; publish a mapping table with paragraph anchors and "indicator, not finding" wording | F-08, F-10, F-11, F-21 | Signed review note; every reference has an anchor and actor |
| 2.2 | Field benchmark on 20–30 public agent repositories with pre-registered expectations and adjudication by two reviewers | F-48, C-19, C-20 | Published precision/recall with CIs and per-rule breakdown; disagreements logged |
| 2.3 | Regression corpus in CI with a precision floor (e.g. ≥ 0.80 on the curated set) and a "no new FP" gate | F-50 | CI fails on a >2-point precision drop |
| 2.4 | India pack 1.0: consent UI, children, cross-border, erasure, SDF checklist; per-pack scoring | — | Precision ≥ 0.70 for indicators; human-review items never emitted as findings |
| 2.5 | Multi-jurisdiction output: separate scores per instrument, no cross-jurisdiction averaging | — | Snapshot shows one block per pack; combined score is absent |
| 2.6 | Design-partner pilot (5–10 teams) with data-handling agreement and a published case study (anonymised) | — | See pilot checklist below |
| 2.7 | Decide build-vs-partner for runtime: integrate garak/promptfoo or link out; do not build a red-team engine | — | Documented decision; no runtime probes in the static scanner |
| 2.8 | Node support matrix (16/18/20/22/24) or raise `engines` to the tested floor | F-49 | CI matrix green; README states the tested floor |

**Exit criterion for Phase 2:** the project can say, with evidence: "On N
repositories, this found X% of adjudicated indicators at Y% precision; the
mapping was reviewed by counsel on DATE; it is not a compliance assessment."
Until that sentence is true, do not use the word "validated".

---

## Design-partner pilot checklist

### Scope and consent
- [ ] Written scope: read-only local scan; no code leaves the partner's machine
      unless they choose to send `report.json`.
- [ ] Explicit statement that `report.json` contains **code excerpts** (PII
      patterns redacted, secrets masked), so sharing it shares source fragments.
- [ ] Terms version recorded in the consent log; `--yes` documented as explicit
      agreement for CI.
- [ ] No training on partner code; no telemetry; no "anonymised pattern" reuse
      without a separate opt-in.

### Data handling
- [ ] Retention: reports deleted after N days unless the partner asks to keep
      them; documented owner and deletion method.
- [ ] Access: named individuals only; no shared drives; no subprocessors without
      disclosure.
- [ ] Incident path: if a report is lost or exposed, notify the partner within
      72 hours (align with DPDP Rule 7 practice even if not yet in force).
- [ ] If the partner is in India: check whether they are a Significant Data
      Fiduciary; if so, the pilot's own DPIA/DPO requirements may apply to the
      engagement.
- [ ] If the partner is in the EU: the pilot processes code, not personal data,
      but snippets can contain personal data; document the lawful basis and
      minimisation.

### Success metrics (pre-register before the pilot)
- [ ] Time to first useful finding (< 10 minutes from `npx` to a triaged list).
- [ ] Percentage of findings the partner confirms as real (target ≥ 50%).
- [ ] Percentage of confirmed issues the partner says they would have missed
      (the actual value signal).
- [ ] Whether any finding changed a release decision (yes/no, with example).
- [ ] Would the partner run it again (yes/no).

### Exit criteria
- [ ] 5 partners completed; ≥ 3 say they would run it again.
- [ ] At least one confirmed issue that the partner's existing tools missed.
- [ ] FP burden documented per rule; any rule above 50% FP is reworked or
      demoted before wider release.
- [ ] No partner describes the output as a "compliance certificate" after
      reading it — if they do, the applicability block failed.

---

## Do not build

| Temptation | Why not | Do instead |
|---|---|---|
| A general SAST engine | Semgrep has 30+ languages and 20k rules | Keep 12 narrow rules; link to Semgrep |
| A secret scanner | Gitleaks is feature-complete and free | Keep `IDENTITY_KEY` as a convenience; defer to Gitleaks |
| An IaC policy engine | Checkov has 1,000+ policies and suppression | Keep `IAM_WILDCARD` as one indicator |
| A runtime red-team | garak and promptfoo exist and are better | Integrate or link out |
| A hosted dashboard/SaaS | Changes the privacy story and the threat model | Stay local; export SARIF/JSON |
| A "compliance score" | The score already causes the worst confusion | Publish severity counts + per-rule coverage, or remove the score |

## Sequencing rule

If only one week is available, do Phase 0 items 0.1, 0.2, 0.3, 0.4. That is
enough to make the product honest. Everything else is capability.
