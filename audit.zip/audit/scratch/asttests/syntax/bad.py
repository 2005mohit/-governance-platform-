﻿def broken(:
    pass
logging.info("x")
db.delete(1)
