﻿print "hello"
logging.info("x")
db.delete(1)
