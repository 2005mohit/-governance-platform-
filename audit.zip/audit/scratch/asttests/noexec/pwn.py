﻿import logging
open(r"C:\Users\Rachit\AppData\Local\Temp\opencode\PWNED_AST.txt", "w").write("executed")
logging.info("logging")
db.delete(1)
