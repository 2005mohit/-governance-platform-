# India pack design — DPDP + CERT-In + guidance

Status: design only. Nothing in this file is implemented; the shipped tool has
one jurisdiction (EU) and no `--pack` flag. This document specifies what a
credible India pack would need, so the work is not a copy-paste of the EU YAML.

## 1. Why a separate pack, not more EU rules

The EU pack encodes one legal frame: high-risk systems, provider design duties,
Annex III use cases. India's frame is different:

- **DPDP Act 2023** is a data-protection statute addressed to **Data Fiduciaries**
  (controllers) and **Data Processors**, not to "AI providers". Its triggers are
  notice, consent, security safeguards, breach intimation, erasure, children, SDF
  duties, and cross-border transfer.
- **CERT-In Directions (28 Apr 2022)** are binding cyber-incident and log-retention
  directions addressed to service providers/intermediaries.
- **MeitY India AI Governance Guidelines (5 Nov 2025)** are **non-binding**
  guidance ("Do No Harm" as the core principle; seven Sutras; six pillars).
- **RBI FREE-AI report (13 Aug 2025)** is an advisory report (7 Sutras, 26
  recommendations, six strategic pillars), not a rulebook.

A single `article: "Article 14"` string cannot represent this. The pack needs
instrument + provision + actor + applicability, and the report needs to say
which instrument it is talking about.

## 2. Provenance and confidence of the legal facts used

| Fact | Status | Source |
|---|---|---|
| DPDP Act 2023 s.5 (notice), s.6(1) (free/specific/informed/unconditional/unambiguous consent), s.8(5) (reasonable security safeguards), s.8(6) (breach intimation to the Board and each affected Data Principal), s.8(7) (erasure), s.9 (children; verifiable parental consent; no behavioural tracking/targeted ads), s.10 (SDF: DPO in India, independent auditor, DPIA), s.16 (cross-border restriction by notification) | **VERIFIED** against Indian Kanoon section pages | `indiankanoon.org/doc/102130291/` (s.5), `/15072321/` (s.6), `/186118625/` (s.8), plus s.9/s.10/s.16 pages |
| DPDP Rules 2025 notified 13 Nov 2025 as G.S.R. 846(E); Rule 6 security safeguards; Rule 7 breach intimation with a 72-hour Board clock | **VERIFIED (secondary)**; the Gazette PDF was not directly retrievable, so wording is from a rules tracker that cites the Gazette | `dpdprules.org/rules`, `dpdprules.org/act/schedule` |
| Phases: 13 Nov 2025 (Rules 1, 2, 17–21), 13 Nov 2026 (Rule 4, s.6(9), s.27(1)(d)), 13 May 2027 (main obligations) | **VERIFIED (secondary/interpretive)** — reconcile against the Gazette before shipping | `dpdprules.org/timeline` |
| CERT-In Directions dated 28 Apr 2022; 6-hour incident reporting; 180-day log retention | Direction exists: **VERIFIED** (`cert-in.org.in/Directions70B.jsp`); the 6 h/180 d figures are **UNVERIFIED from the primary PDF** (PDF fetch blocked), corroborated only by secondary summaries | CERT-In page; secondary summaries |
| MeitY India AI Governance Guidelines released 5 Nov 2025; non-binding; "Do No Harm"; seven Sutras; six pillars | **VERIFIED (secondary)**; primary PDF (`static.pib.gov.in/...doc2025115685601.pdf`) was not parseable by the fetch tool | PIB document link; secondary coverage |
| RBI FREE-AI report 13 Aug 2025; 7 Sutras; 26 recommendations; six pillars | **VERIFIED (secondary)**; RBIDocs PDF is behind a bot challenge | `rbi.org.in` press release `prid=61018`; secondary coverage |
| IT Act s.43A / SPDI Rules 2011 | **UNVERIFIED for transitional status after DPDP** — do not ship a rule until counsel confirms what still applies | — |

Rule of thumb for the pack: **never** print a penalty figure, a compliance
verdict, or a phase date without a citation field in the finding.

## 3. Required schema changes

### 3.1 Pack metadata

```yaml
pack:
  id: india_dpdp
  version: 0.1.0
  jurisdiction: IN
  instrument: "Digital Personal Data Protection Act, 2023"
  effective: "2023-08-11"          # assent
  phases:
    - date: "2025-11-13"
      note: "Rules 1, 2, 17-21"
    - date: "2027-05-13"
      note: "main obligations (secondary/interpretive)"
  actor: "Data Fiduciary"
  applicability: "processing of digital personal data in India"
  disclaimer: "Indicators for review, not a compliance determination."
rules: []
```

### 3.2 Rule shape (superset of today's)

```yaml
- id: IN_DPDP_BREACH_NOTIFY
  title: "Breach path without intimation to the Board"
  references:
    - instrument: "DPDP Act 2023"
      provision: "s.8(6)"
      actor: "Data Fiduciary"
      appliesTo: "personal-data breach"
    - instrument: "DPDP Rules 2025"
      provision: "r.7"
      actor: "Data Fiduciary"
      note: "72-hour Board clock (secondary)"
  severity: HIGH
  confidence: medium            # static indicator; human review required
  detector:
    type: sink_absence          # new: look for a handler and a missing notify call
    handlerPatterns: ["except\\s+Exception", "catch\\s*\\(", "on_error"]
    requiredPatterns: ["notify.*board", "report.*incident", "cert-in", "data.*principal"]
    windowLines: 60
  remediation: "…"
  falsePositiveNote: "…"
```

New detector types the engine needs:

| Type | Use | Example |
|---|---|---|
| `pii_value` | regex + checksum on literal values in code/logs/prompts | Aadhaar, PAN, +91, UPI |
| `sink_absence` | a handler/route exists but a required call is absent in its window | breach notify, erasure |
| `config_value` | read a config key and compare to a policy | log retention, region |
| `consent_ui` | pre-ticked/bundled consent markers in templates | s.6(1) |
| `human_review` | no detector; emit a checklist prompt with a file anchor | SDF duties, MeitY Sutras |

### 3.3 Multi-mapping and multi-pack

- `references` is a list, not a string. The report renders one row per reference.
- `--pack <id|path>` repeatable; `--pack all` runs EU + India.
- Each pack gets its own score and band; **never** average across jurisdictions.
  Output: `jurisdictions: [{id, score, band, rulesRun, findings}]`.
- `packId` and `packVersion` on every finding, so consumers can filter.
- A finding that maps to two instruments (e.g. Aadhaar exposure → DPDP s.8(5)
  and CERT-In security direction) appears once with two references, not twice.

## 4. Proposed India rules

Labels: **S** = static check with validation, **I** = static indicator,
**H** = human review only (no detector). "FP risk" is the dominant false
positive to design against.

| # | Rule id | Provision | Detector | Sev | Label | What it actually sees | FP risk / guard |
|---|---|---|---|---|---|---|---|
| 1 | `IN_DPDP_NOTICE` | s.5 | `consent_ui` + string search for purpose/notice link near a consent call | HIGH | I | A consent/collect flow with no notice text, purpose, or rights link in the same module | Consent may be rendered by a shared component; require a project-level notice sink before firing |
| 2 | `IN_DPDP_CONSENT_QUALITY` | s.6(1) | `consent_ui` for pre-ticked defaults, "by continuing you agree", bundled purposes | MEDIUM | I | UI/template literals that suggest bundled or implied consent | Marketing copy may be unrelated; anchor to a consent handler |
| 3 | `IN_DPDP_SECURITY` | s.8(5) | `pii_value` + config checks (plaintext PII columns, public bucket, no TLS) | HIGH | I | PII literals in code/logs, public storage config, `http://` endpoints handling PII | Test fixtures and synthetic data; allow `# synthetic` / path allowlist |
| 4 | `IN_DPDP_BREACH_NOTIFY` | s.8(6) + r.7 | `sink_absence` | HIGH | I | An exception/incident handler with no Board/Data Principal notification path and no 72 h constant | Notify may live in a shared module; resolve imports before firing |
| 5 | `IN_DPDP_ERASURE` | s.8(7) | `sink_absence` on account-delete/retention code | MEDIUM | I | Delete endpoint that removes the row but not derived stores/logs/backups | Retention may be intentional; require a retention policy config to suppress |
| 6 | `IN_DPDP_CHILD_CONSENT` | s.9 | `consent_ui` for age gate / parental consent; `human_review` for behavioural tracking | HIGH | I/H | No age gate in a consumer-facing flow; analytics/targeting calls near child-directed content | Cannot know the audience statically; require the repo to declare `audience: children` |
| 7 | `IN_DPDP_SDF_DUTIES` | s.10 | `human_review` | MEDIUM | H | Prompt for DPO-in-India, independent auditor, DPIA evidence | Not statically checkable; never emit as a finding, emit as a question |
| 8 | `IN_DPDP_CROSS_BORDER` | s.16 | `config_value` (region/endpoint allowlist) + `human_review` | MEDIUM | I/H | Data sent to a region outside the notified list, or no region pinning | s.16 is notification-driven; the list changes; require a versioned allowlist |
| 9 | `IN_CERTIN_INCIDENT_6H` | CERT-In Directions 2022 | `sink_absence` + constant search (`6h`, `21600`) | HIGH | I | Incident path with no CERT-In report call / no 6-hour clock | Direction applies to service providers; confirm the repo operates a service |
| 10 | `IN_CERTIN_LOG_180D` | CERT-In Directions 2022 | `config_value` | MEDIUM | I | Log retention configured below 180 days (when a retention setting exists) | Only fires when a retention value is found; absence is a human-review prompt |
| 11 | `IN_PII_AADHAAR` | s.8(5) (security) | `pii_value` with Verhoeff checksum | HIGH | S | 12-digit Aadhaar-shaped values that pass Verhoeff, in code/logs/prompts | Test data; validate checksum first, then require a PII sink |
| 12 | `IN_PII_PAN` | s.8(5) | `pii_value` regex + format | HIGH | S | `[A-Z]{5}[0-9]{4}[A-Z]` in code/logs | Sample PANs in docs; allowlist `ABCDE1234F`-style examples |
| 13 | `IN_PII_UPI` | s.8(5) | `pii_value` VPA shape | MEDIUM | I | `name@bank` handles in code/logs | Emails look similar; require a bank-handle allowlist |
| 14 | `IN_PII_PHONE_91` | s.8(5) | `pii_value` `+91[6-9]\d{9}` | MEDIUM | I | Indian mobile numbers in code/logs | Placeholder numbers; allowlist 000/111 sequences |
| 15 | `IN_MEITY_DO_NO_HARM` | MeitY Guidelines (non-binding) | `human_review` | LOW | H | Prompt: documented harm assessment, red-team, escalation | Guidance is non-binding; never present as a legal finding |
| 16 | `IN_RBI_FREE_AI` | RBI FREE-AI (advisory) | `human_review` | LOW | H | Prompt: accountability, auditability, fairness evidence for financial agents | Advisory only; scope to BFSI repos |
| 17 | `IN_IT_ACT_43A` | IT Act s.43A (legacy) | **do not ship** until transitional status is confirmed | — | — | — | UNVERIFIED after DPDP; omit |

Why these and not "Aadhaar = DPDP s.5": a PII literal is evidence of a security
gap (s.8(5)), not of a notice failure. Mapping every PII hit to s.5 would repeat
the exact mistake the EU pack makes with Art. 9.

## 5. Detector details that matter

### 5.1 Aadhaar (checksum, not just regex)
- Shape: 12 digits, first digit 2–9, no all-zero/all-one.
- Verhoeff checksum over the 12th digit. Implementation is ~20 lines; unit-test
  against published valid/invalid examples.
- Emit only the masked value (`XXXX XXXX 1234`) plus file:line; never the full
  number in `report.json` or HTML.
- If the checksum fails, do not emit. A 12-digit order ID must not become a
  "sensitive data" finding.

### 5.2 PAN
- Shape: `[A-Z]{5}[0-9]{4}[A-Z]`; the 4th character encodes holder type
  (`P` individual, `C` company, etc.). Do not claim validity beyond shape.
- Exclude known documentation examples (`ABCDE1234F`) and test fixtures.

### 5.3 +91 and UPI
- `+91` must be followed by 10 digits starting 6–9; allow spaces/hyphens.
- UPI: `localpart@handle` where handle is a known bank/PSP list; otherwise it
  collides with email. Maintain the handle list in the pack, not in code.

### 5.4 Consent UI
- Look for: `checked`/`defaultChecked` on a consent checkbox, `by (continuing|
  using|clicking) you agree`, a single checkbox covering multiple purposes,
  `required=false` on a consent field.
- Do not fire on a privacy-policy *link* alone; a link is not consent.
- This is an indicator, not proof: the actual notice may be server-rendered.

### 5.5 Breach notification
- `sink_absence` is the only honest static form: "a handler exists; no notify
  path is visible in this module (or its direct imports)".
- The 72-hour figure is a **Rule 7** duty; the 6-hour figure is **CERT-In**.
  They are different clocks for different recipients. Do not merge them into one
  "6/72h" finding — that is the kind of error that loses a legal reviewer.

### 5.6 Log retention
- Only fire when a retention value is *found* and is below 180 days. Absence of a
  setting is a question, not a finding.

## 6. Redaction and data handling

Extend `redactPII` (`src/utils.js:10–40`) with India patterns, but keep the
existing rule: **detect on raw text, redact only when building evidence**.

| Pattern | Output |
|---|---|
| Aadhaar | `[REDACTED_AADHAAR]` (keep last 4 only if needed for triage) |
| PAN | `[REDACTED_PAN]` |
| UPI VPA | `[REDACTED_UPI]` |
| +91 phone | `[REDACTED_PHONE_IN]` |

Additional requirements:
- Never write a raw Aadhaar/PAN/UPI value to the consent log, stderr, or HTML.
- Add a test that scans a fixture containing all four and asserts the raw strings
  appear nowhere in `report.json`/`report.html`.
- The report should state that redaction is pattern-based and can miss values.

## 7. Scoring and output

- Per-pack score, per-pack band. Do not sum EU + India penalties into one number;
  a 0–100 "readiness" score across two legal regimes is not meaningful.
- Report sections:
  1. Applicability (instrument, actor, phase, "not a compliance determination").
  2. Findings grouped by instrument, not by "risk area".
  3. Human-review checklist (SDF, MeitY, RBI) separate from findings.
  4. Coverage matrix: rule → provision → detector type → what was not checked.
- Each finding carries `confidence: static-validated | static-indicator |
  human-review` and the pack version.
- No "compliant"/"non-compliant" words anywhere. Use "indicator", "review
  prompt", "not checked".

## 8. Fixtures (minimum)

For each rule: one positive, one negative, one evasion, one FP trap.

| Rule | Positive | Negative | Evasion | FP trap |
|---|---|---|---|---|
| NOTICE | consent call, no notice string | consent + purpose + rights link | notice from CMS/API | privacy-policy link only |
| CONSENT_QUALITY | pre-ticked box | explicit unchecked box | consent hidden in T&C | marketing "agree" copy |
| SECURITY | PII literal in log | encrypted column + TLS | PII in a prompt file | synthetic fixture path |
| BREACH | handler, no notify | handler + Board notify | notify in shared module | generic error logger |
| ERASURE | delete endpoint only | delete + derived-store purge | soft delete + cron | retention-by-design config |
| CHILD | no age gate in declared child app | verifiable parental consent | age gate in another service | adult-only declared app |
| CROSS_BORDER | region `us-east-1` for PII | region `ap-south-1` + allowlist | endpoint from env | analytics without PII |
| CERT 6H | no CERT-In call | CERT-In report + 6 h | shared incident SDK | internal-only incident |
| CERT 180D | retention 30 d | 180 d | retention in infra repo | no retention setting |
| AADHAAR | valid Verhoeff | invalid checksum | spaced digits | 12-digit order id |
| PAN | valid shape | lowercase/near-miss | split across concatenation | `ABCDE1234F` example |
| UPI | real handle | email | handle from config | `user@example.com` |
| PHONE | `+91 98…` | `+1 …` | `0091…` | `+91 0000000000` |

Acceptance: on this fixture set, precision ≥ 0.85 for the `S` rules (validated
PII) and ≥ 0.70 for `I` rules; zero raw PII in output; deterministic across 3
runs.

## 9. Implementation plan and touchpoints

| Change | File | Notes |
|---|---|---|
| Multi-pack loading + `--pack` | `src/cli.js:124` | Replace the single hard-coded path; accept repeatable flag and a config file |
| `references[]` + `packId` on findings | `src/scanner.js:682–725` | Keep `article` as a derived display string for backward compatibility |
| Pack schema validation | new `src/rules.js` | Validate ids, severity enum, detector type, references, regex compiles; fail with file/rule/field |
| PII detectors + Verhoeff | new `src/pii.js` (pure functions) | Unit-testable without filesystem |
| `sink_absence` / `config_value` detectors | `src/scanner.js` | New branches next to the existing `logic` dispatch (`:430–442`) |
| Per-pack scoring | `src/reporter.js:24–45` | Return an array of pack scores; HTML renders one block per pack |
| India redaction | `src/utils.js:10–40` | Add patterns; keep detect-before-redact |
| India pack | `rules/india_dpdp.yaml` | 14 rules + 3 human-review prompts (not 17 findings) |
| Fixtures | `audit/corpus-india/` + runner | Same manifest format as the EU corpus |
| Docs | README + report | "India pack: static indicators for DPDP/CERT-In; guidance prompts for MeitY/RBI" |

## 10. What not to claim

- Do not say "DPDP compliant" or "CERT-In compliant". The pack checks code
  patterns; compliance depends on notices, contracts, DPIAs, audits, and
  organisational practice.
- Do not print penalties (₹250 crore etc.) next to findings. Penalty exposure is
  a legal assessment, not a static-analysis output.
- Do not merge the DPDP 72-hour and CERT-In 6-hour clocks.
- Do not treat MeitY Guidelines or the RBI report as binding law.
- Do not use "Aadhaar detected" as a proxy for "consent missing". They are
  different provisions with different remedies.

## 11. Minimum viable India release

If time is short, ship only rules 3, 4, 9, 10, 11, 12 and the three
human-review prompts. That set is defensible: security safeguards, breach
notification, CERT-In clocks, and checksum-validated Aadhaar/PAN. It avoids the
consent-UI and children rules, which need product context the scanner cannot
see. Label the pack **0.1.0 / experimental** and keep it opt-in via `--pack`.
