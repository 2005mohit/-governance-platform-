const fs = require("fs");
const path = require("path");
const base = path.join(process.env.TEMP || "/tmp", "opencode", "redos");
fs.rmSync(base, { recursive: true, force: true });
fs.mkdirSync(base, { recursive: true });
const cases = {
  a1m: "a".repeat(1024 * 1024),
  quote1m: '"'.repeat(1024 * 1024),
  sk1m: "sk-".repeat(350000),
  action1m: "Action = ".repeat(120000),
  paren1m: "torch.load(" + ")".repeat(500000),
  emailish: "a.".repeat(500000),
};
for (const [n, c] of Object.entries(cases)) {
  fs.mkdirSync(path.join(base, n), { recursive: true });
  fs.writeFileSync(path.join(base, n, "x.py"), c);
}
fs.mkdirSync(path.join(base, "nul"), { recursive: true });
fs.writeFileSync(
  path.join(base, "nul", "x.py"),
  Buffer.from([0x58, 0x3d, 0x00, 0x00, 0xff, 0xfe, 0x0a, 0x64, 0x62, 0x2e, 0x64, 0x65, 0x6c, 0x65, 0x74, 0x65, 0x28, 0x31, 0x29])
);
console.log(base);
