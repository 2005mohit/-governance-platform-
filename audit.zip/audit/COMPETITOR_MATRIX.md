# Competitor matrix (verified facts, 2026-11-12)

Purpose: answer "what would a real AI company use instead, and where — if
anywhere — does `ai-risk-snapshot` have a defensible position?"

Method: official repository READMEs, GitHub REST metadata, and PyPI JSON, read
on 2026-11-12. No hands-on precision benchmark of competitor tools was run, so
capability claims are **VERIFIED as vendor statements**, not independently
measured. Licence and star counts come from the GitHub API.

## 1. Matrix

| Tool | Category | Scope / languages | Runs locally | CI artefacts | Baseline / suppression | Licence | Source |
|---|---|---|---|---|---|---|---|
| **Semgrep** | SAST | 30+ languages; 20k+ proprietary rules; secrets and SCA in the platform | Yes, "by default, code is never uploaded" | SARIF, IDE, pre-commit, PR diff scanning | Yes (platform triage; CE config-level) | LGPL-2.1 (CE) | `github.com/semgrep/semgrep` |
| **Gitleaks** | Secrets | Git repos, files, stdin; regex + entropy | Yes | JSON/SARIF, pre-commit, fingerprints per finding | Yes (`.gitleaksignore`, fingerprints) | MIT | `github.com/gitleaks/gitleaks` |
| **Checkov** | IaC + SCA | 1,000+ built-in policies; AWS/Azure/GCP; images; open-source packages | Yes | CLI, CycloneDX, JSON, JUnit XML, CSV, SARIF | Yes (inline suppression, skip-check) | Apache-2.0 | `github.com/bridgecrewio/checkov` |
| **Bandit** | Python SAST | Python AST; common security issues | Yes | JSON, SARIF, text | Yes (`# nosec`, baseline) | Apache-2.0 | `github.com/PyCQA/bandit` |
| **garak** | LLM red-team | Probes a running LLM/dialog system (hallucination, leakage, injection, jailbreak, XSS, toxicity) | Yes (local models via transformers) | JSON/HTML reports | Probe selection | Apache-2.0 | `github.com/NVIDIA/garak` |
| **promptfoo** | LLM evals / red-team | Prompt/agent/RAG evaluation and red-teaming; code scanning for LLM issues | Yes ("evals run 100% locally") | CLI + CI integration, JSON | Config-driven | MIT | `github.com/promptfoo/promptfoo` |
| **AIR Blackbox MCP** | EU AI Act agent scanner (closest direct competitor) | 6 EU AI Act articles; Python, notebooks, TypeScript, JavaScript, Java, Kotlin with SDK (Python without) | Yes (local MCP server; optional local Ollama model) | MCP tools: `scan_code`, `suggest_fix`, `validate_action`, `explain_article` | Not stated in README | Apache-2.0 | `github.com/airblackbox/air-blackbox-mcp` |
| **compliance-agent 0.6.1** | EU AI Act scanner (PyPI) | "EU AI Act compliance scanner for AI projects"; Python package, Typer CLI, WeasyPrint PDF | Yes | CLI + PDF; optional `fastmcp` extra | Not stated | MIT | `pypi.org/project/compliance-agent` |
| **ai-risk-snapshot 1.1.0** | EU AI Act-oriented static indicator scanner | 12 regex/AST rules; `.py .js .ts .jsx .tsx .tf .yaml .yml .json .env*`; 5 of 12 rules are agent-action rules | Yes (no network in `src/`) | JSON + HTML only | None | MIT (repo) | local audit |

Notes:
- `compliance-agent`'s PyPI metadata lists `weasyprint`, `typer`, `pydantic`,
  `pyyaml`, `rich` — i.e. a Python CLI that emits PDF. The summary is the only
  capability claim available without installing it.
- A search for "ShadowAudit" returned unrelated products (Web3 payment
  abstraction, API security, binary fuzzing). No verifiable AI-agent compliance
  product by that name was found; do not cite it as a competitor.

## 2. Where each competitor actually wins

| Buyer need | Winner | Why |
|---|---|---|
| "Find secrets now" | **Gitleaks** | Purpose-built, entropy + regex, fingerprints, `.gitleaksignore`, pre-commit. `IDENTITY_KEY` is a subset. |
| "Scan my IaC" | **Checkov** | 1,000+ policies, inline suppression, SARIF. `IAM_WILDCARD` is one Checkov policy. |
| "Python security baseline" | **Bandit** | AST-based, `# nosec`, baseline, SARIF, Apache-2.0. `UNSAFE_DESERIALIZE` overlaps. |
| "General SAST with custom rules" | **Semgrep** | 30+ languages, local by default, SARIF, 20k+ rules; a user can write the entire `ai-risk-snapshot` pack in Semgrep YAML in an afternoon. |
| "Test my running agent" | **garak / promptfoo** | Dynamic probes and evals. `ai-risk-snapshot` cannot do this and should not imply it can. |
| "EU AI Act-specific agent scan" | **AIR Blackbox MCP** | 6 articles, 6 languages + SDK, remediation, pre-execution `validate_action` (Art. 14), Apache-2.0, MCP-native. |
| "EU AI Act scan from Python" | **compliance-agent** | MIT, PyPI-installable, PDF output. |
| "Offline, no-account, one-command review of agent code" | **ai-risk-snapshot** (only if repositioned) | No Python SDK required, no config, HTML for a human, 11-file install. |

## 3. Where `ai-risk-snapshot` is actually differentiated

Only three things are not commodity:

1. **Zero-config, human-readable HTML** aimed at a developer or auditor rather
   than a CI dashboard. Semgrep/Checkov/Bandit output is for engineers; the
   HTML "plain language" card is a real differentiator.
2. **Agent-action taxonomy tied to oversight/logging** (`NO_HUMAN_LOOP`,
   `NO_LOGGING`, `SAFETY_BYPASS`). Bandit/Checkov do not attempt this, and AIR
   Blackbox's `validate_action` is runtime, not static.
3. **A written legal-mapping narrative** (the paper). Competitors ship rules,
   not a documented mapping rationale. That is an asset only if the mapping is
   correct — today it is not (see `RULE_VALIDATION.md`).

Everything else is weaker than a free incumbent: secrets (Gitleaks), IaC
(Checkov), Python AST (Bandit), languages and rules (Semgrep), runtime
(garak/promptfoo), EU breadth (AIR Blackbox).

## 4. The "single framework" gap the project claims

`Project Overview.md:3` says existing tools "check for a single framework and
only inspect static code", and that no affordable tool checks "both code-level
and dataset-level compliance risk against more than one jurisdiction's rules in
a single scan".

Verified position on 2026-11-12:

- **Single framework**: Semgrep/Checkov/Bandit are framework-agnostic security
  tools, not "single AI framework" tools; the claim as worded is misleading.
- **Static only**: garak and promptfoo are dynamic, so "existing tools only
  inspect static code" is false.
- **More than one jurisdiction**: `ai-risk-snapshot` ships **one** jurisdiction
  (EU). The README's India pack does not exist (F-44). The paper correctly calls
  India "future work". So the differentiator is currently a roadmap item, not a
  capability.
- **Dataset-level**: `SENSITIVE_DATA` is filename-only and cannot inspect
  datasets (F-07). The claim is not supported.

## 5. Implication for positioning

There is one defensible niche: **"the offline, zero-config first-pass that tells
a small team which agent behaviours to review, with an honest confidence label
and a plain-language report."** That niche is real because Semgrep et al. are
intimidating for a 3-person team and produce security findings, not
oversight/logging prompts.

It is not defensible as:
- a compliance product (no applicability, wrong articles),
- a CI product (no exit codes/SARIF/baseline),
- a multi-jurisdiction product (EU only),
- a dataset/privacy product (filename-only),
- a replacement for Semgrep/Gitleaks/Checkov/Bandit (strict subset on their
  dimensions).

Recommended public wording: "A local first-pass that surfaces selected agent
oversight and logging patterns for human review. It is not a compliance
assessment and does not replace SAST, secret scanning, or IaC scanning." That
sentence is defensible today; the current README is not.
